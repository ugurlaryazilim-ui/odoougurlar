# fal.ai provider implementation.
#
# fal_client SDK kullanir - kuyruk destekli, otomatik retry,
# timeout yonetimi ve yapisal hata ayristirma entegrasyonu ile.

import base64
import logging

from .ai_provider_base import AIProviderBase

_logger = logging.getLogger(__name__)

try:
    import fal_client
except ImportError:
    fal_client = None
    _logger.warning(
        'fal-client kurulu degil. AI ozellikleri calismayacak. '
        'Kurulum: pip install fal-client'
    )


class FalProvider(AIProviderBase):
    # fal.ai FASHN v1.6 implementasyonu.
    #
    # Tum API cagrilari fal_client.subscribe() ile yapilir:
    # - Kuyruk destekli (otomatik retry, 10 kez)
    # - client_timeout ile zaman asimi kontrolu
    # - on_queue_update ile ilerleme takibi

    ENDPOINTS = {
        'tryon_fashn': 'fal-ai/fashn/tryon/v1.6',
        'tryon_kolors': 'fal-ai/kling/v1-5/kolors-virtual-try-on',
        'bg_remove': 'fal-ai/birefnet',
        'flux_schnell': 'fal-ai/flux/schnell',
        'flux_pro': 'fal-ai/flux-pro/v1.1',
        'nano_banana': 'fal-ai/nano-banana-2/edit',
        'any_llm': 'fal-ai/any-llm',
    }

    # Endpoint basina tahmini maliyet (USD)
    ESTIMATED_COSTS = {
        'fal-ai/fashn/tryon/v1.6': 0.075,
        'fal-ai/birefnet': 0.002,
        'fal-ai/flux/schnell': 0.003,
        'fal-ai/flux-pro/v1.1': 0.05,
        'fal-ai/nano-banana-2/edit': 0.04,
        'fal-ai/any-llm': 0.001,
    }

    def __init__(self, api_key):
        import os
        os.environ['FAL_KEY'] = api_key
        self.api_key = api_key

    def _check_client(self):
        if fal_client is None:
            raise ImportError(
                'fal-client paketi kurulu degil. '
                'Kurulum: pip install fal-client'
            )

    def get_estimated_cost(self, endpoint):
        # Endpoint icin tahmini maliyeti dondur (USD).
        return self.ESTIMATED_COSTS.get(endpoint, 0.01)

    def virtual_tryon(self, model_image_url, garment_image_url,
                      category='tops', mode='balanced', **kwargs):
        # Manken uzerine giydirme.
        self._check_client()

        # default endpoint mapping based on model_name
        model_name = kwargs.get('model_name') or 'tryon-v1.6'
        endpoint = kwargs.get('endpoint')
        if not endpoint:
            if 'nano-banana' in model_name:
                endpoint = self.ENDPOINTS['nano_banana']
            elif 'max' in model_name:
                endpoint = 'fal-ai/fashn/tryon-max'
            elif 'v1.6' in model_name or 'v1-6' in model_name:
                endpoint = self.ENDPOINTS['tryon_fashn']
            else:
                endpoint = self.ENDPOINTS['tryon_fashn']  # Default to FASHN v1.6 for best quality

        prompt = kwargs.get('prompt', '')

        if 'nano-banana' in endpoint:
            # nano-banana-2/edit formatı
            # View-spesifik prompt bilgisini ekle
            photo_type = kwargs.get('photo_type', 'front')
            front_output_url = kwargs.get('front_output_url')
            detail_urls = kwargs.get('detail_urls') or []
            
            image_urls_list = [garment_image_url, model_image_url]
            if front_output_url and photo_type in ('back', 'side'):
                image_urls_list.append(front_output_url)
                
            for du in detail_urls:
                image_urls_list.append(du)
                
            enhanced_prompt = prompt
            
            # Base View Hints
            view_hints = {
                'back': 'IMPORTANT: Show the BACK view of the model, facing away from camera. ',
                'side': 'IMPORTANT: Show the SIDE view of the model, turned 45 degrees. ',
                'detail': 'IMPORTANT: Close-up detail shot showing fabric texture and details. ',
            }
            base_hint = view_hints.get(photo_type, '') if photo_type and photo_type != 'front' else ''
            dynamic_prompt = base_hint
            
            detail_start_idx = 3
            if front_output_url and photo_type in ('back', 'side'):
                dynamic_prompt += "The THIRD reference image is the FRONT generated view of this model; you MUST use the THIRD image as the absolute source of truth for the model identity, hairstyle, skin, and ALL other outfit parts (like top, bottom, shoes). Do NOT change the model or the rest of the outfit from the THIRD reference image. ONLY rotate the camera to show the view, and apply the new garment. "
                detail_start_idx = 4
                
            if detail_urls:
                for i in range(len(detail_urls)):
                    idx = detail_start_idx + i
                    
                    # Sayı sonlarına uygun ek getirme (1st, 2nd, 3rd, 4th, vb.)
                    suffix = "th"
                    if idx % 10 == 1 and idx % 100 != 11:
                        suffix = "st"
                    elif idx % 10 == 2 and idx % 100 != 12:
                        suffix = "nd"
                    elif idx % 10 == 3 and idx % 100 != 13:
                        suffix = "rd"
                        
                    dynamic_prompt += f"The {idx}{suffix} reference image is a MACRO DETAIL shot of the garment (showing fabric texture, buttons, or specific patterns). You MUST accurately apply this exact texture and detail to the garment. DO NOT hallucinate details. DO NOT modify, invent, or change any buttons, patterns, prints, textures, or hardware visible in this reference. Copy them EXACTLY. "
                
                # CRITICAL: Prevent the AI from hallucinating a macro shot as the main output
                dynamic_prompt += (
                    "CRITICAL: The final output MUST BE a FULL BODY photograph of the human model wearing the garment. "
                    "DO NOT generate a macro shot. DO NOT generate a close-up of the detail. "
                    "The macro detail image is strictly for texture and button reference only. "
                    "The model (mannequin) must remain fully visible in the shot. "
                    "GARMENT DETAIL ANTI-HALLUCINATION: The garment in the output MUST be a pixel-perfect match "
                    "of the 1st reference image (garment photo). Count the buttons — reproduce the EXACT count. "
                    "Match the pattern — do NOT simplify or reinterpret any print, stripe, or graphic. "
                    "Match the hardware — same zippers, snaps, rivets. Any deviation is a failure. "
                )
                    
            if dynamic_prompt:
                enhanced_prompt = dynamic_prompt + "\n" + enhanced_prompt

            arguments = {
                'prompt': enhanced_prompt,
                'image_urls': image_urls_list,
                'num_images': kwargs.get('num_samples', 1),
                'aspect_ratio': '2:3',
                'output_format': 'png',
                'safety_tolerance': '4',
                'resolution': kwargs.get('resolution', '2K'),
                'limit_generations': True,
                'enable_watermark': False,
            }
            if 'negative_prompt' in kwargs and kwargs['negative_prompt']:
                arguments['negative_prompt'] = kwargs['negative_prompt']
            if 'seed' in kwargs and kwargs['seed']:
                arguments['seed'] = int(kwargs['seed'])
        else:
            # FASHN v1.6 veya Kolors formatı
            fal_category = {
                'tops': 'tops',
                'bottoms': 'bottoms',
                'one_piece': 'one-piece',
                'one-piece': 'one-piece',
                'shoes': 'tops',
                'bags': 'tops',
                'accessories': 'tops',
            }.get(category, 'tops')

            arguments = {
                'model_image': model_image_url,
                'garment_image': garment_image_url,
                'category': fal_category,
                'mode': mode,
                'garment_photo_type': kwargs.get('garment_photo_type', 'flat-lay'),
                'enable_watermark': False,
            }
            if prompt:
                arguments['prompt'] = prompt
            if 'negative_prompt' in kwargs and kwargs['negative_prompt']:
                arguments['negative_prompt'] = kwargs['negative_prompt']
            if 'seed' in kwargs and kwargs['seed']:
                arguments['seed'] = int(kwargs['seed'])

        # Rate Limit / Concurrency Limit Retry Mekanizması
        import time
        max_retries = 3
        backoff_factor = 4
        result = None
        for attempt in range(max_retries):
            try:
                result = fal_client.subscribe(
                    endpoint,
                    arguments=arguments,
                    client_timeout=300,
                )
                break
            except Exception as e:
                error_str = str(e).lower()
                is_rate_limit = (
                    'rate' in error_str or
                    'limit' in error_str or
                    '429' in error_str or
                    'concurrent' in error_str
                )
                if is_rate_limit and attempt < max_retries - 1:
                    sleep_time = backoff_factor * (2 ** attempt)
                    _logger.warning(
                        "fal.ai Rate Limit asildi. %d saniye beklenip tekrar denenecek (Deneme %d/%d). Hata: %s",
                        sleep_time, attempt + 1, max_retries, e
                    )
                    time.sleep(sleep_time)
                else:
                    raise

        image_urls = []
        if 'images' in result and result['images']:
            image_urls = [img.get('url', '') for img in result['images']]
        elif 'image' in result and result['image']:
            image_urls = [result['image'].get('url', '')]

        image_url = image_urls[0] if image_urls else ''
        request_id = result.get('request_id', '')
        
        # fal.ai base response'dan veya result dict'ten seed oku
        seed_val = None
        if isinstance(result, dict):
            seed_val = result.get('seed')
        else:
            seed_val = getattr(result, 'seed', None)

        return {
            'image_urls': image_urls,
            'image_url': image_url,
            'cost': self.get_estimated_cost(endpoint) * len(image_urls) if 'nano-banana' in endpoint else self.get_estimated_cost(endpoint),
            'request_id': request_id,
            'seed': seed_val,
        }

    def remove_background(self, image_base64):
        # Arka plan kaldirma - birefnet.
        self._check_client()

        image_url = self.upload_image(image_base64)
        result = fal_client.subscribe(
            self.ENDPOINTS['bg_remove'],
            arguments={'image_url': image_url},
            client_timeout=60,
        )
        output_url = result.get('image', {}).get('url', '')
        if output_url:
            import requests
            img_data = requests.get(output_url, timeout=60).content
            return base64.b64encode(img_data).decode()
        return image_base64

    def generate_mannequin(self, prompt, **kwargs):
        # AI ile manken fotografi olustur - FLUX schnell.
        self._check_client()

        width = kwargs.get('width', 864)
        height = kwargs.get('height', 1296)

        result = fal_client.subscribe(
            self.ENDPOINTS['flux_schnell'],
            arguments={
                'prompt': prompt,
                'image_size': {'width': width, 'height': height},
                'num_images': 1,
                'enable_watermark': False,
            },
            client_timeout=120,
        )

        image_url = result.get('images', [{}])[0].get('url', '')
        if image_url:
            import requests
            img_data = requests.get(image_url, timeout=60).content
            return base64.b64encode(img_data).decode()
        return None

    def upload_image(self, image_base64, content_type='image/jpeg'):
        # Gorseli fal CDN'e yukle - otomatik retry ve fallback ile.
        self._check_client()
        if isinstance(image_base64, bytes):
            image_base64 = image_base64.decode('ascii')
        if image_base64.startswith('data:'):
            image_base64 = image_base64.split(';base64,', 1)[1]
        image_bytes = base64.b64decode(image_base64)
        return fal_client.upload(image_bytes, content_type)
