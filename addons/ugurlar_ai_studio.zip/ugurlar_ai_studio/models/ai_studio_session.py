import logging
import base64
import threading
import time
import json
import uuid

from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

def _safe_write_and_commit(cr, record, vals, max_retries=5):
    """Concurrent update (SerializationFailure) hatalarını önlemek için güvenli DB yazma."""
    import time, random
    for attempt in range(max_retries):
        try:
            record.write(vals)
            cr.commit()
            return True
        except Exception as e:
            cr.rollback()
            err_str = str(e).lower()
            is_serialization = (
                'serialize access' in err_str or
                'serializationfailure' in str(e.__class__).lower() or
                'current transaction is aborted' in err_str or
                'concurrent update' in err_str
            )
            if is_serialization and attempt < max_retries - 1:
                time.sleep(random.uniform(0.2, 1.5))
                continue
            raise e


class AiStudioSession(models.Model):
    """Ana çekim oturumu modeli.

    Barkod tarama → fotoğraf çekimi → AI işleme → onay/red → ürüne kaydetme
    akışının merkezi yönetim noktası. mail.thread ile bildirim desteği sağlar.
    """
    _name = 'ai.studio.session'
    _description = 'AI Stüdyo Çekim Oturumu'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'create_date desc'
    _rec_name = 'name'

    name = fields.Char(
        string='Oturum No',
        readonly=True,
        default='/',
        copy=False,
    )
    product_id = fields.Many2one(
        'product.product',
        string='Ürün Varyantı',
        required=True,
        tracking=True,
        index=True,
    )
    product_barcode = fields.Char(
        related='product_id.barcode',
        string='Barkod',
    )
    product_image = fields.Image(
        related='product_id.image_128',
        string='Mevcut Ürün Resmi',
    )

    # --- Pivot & Filtreleme Bilgileri ---
    category_id = fields.Many2one(
        'product.category', string='Kategori',
        related='product_id.categ_id', store=True
    )
    qty_available = fields.Float(
        string='Stok Miktarı',
        related='product_id.qty_available', store=True
    )
    color_value_ids = fields.Many2many(
        'product.attribute.value', 'ai_session_color_rel', string='Renk',
        compute='_compute_attributes', store=True
    )
    size_value_ids = fields.Many2many(
        'product.attribute.value', 'ai_session_size_rel', string='Beden',
        compute='_compute_attributes', store=True
    )
    brand_value_ids = fields.Many2many(
        'product.attribute.value', 'ai_session_brand_rel', string='Marka',
        compute='_compute_attributes', store=True
    )
    season_value_ids = fields.Many2many(
        'product.attribute.value', 'ai_session_season_rel', string='Sezon',
        compute='_compute_attributes', store=True
    )
    gender_value_ids = fields.Many2many(
        'product.attribute.value', 'ai_session_gender_rel', string='Cinsiyet',
        compute='_compute_attributes', store=True
    )

    @api.depends('product_id', 'product_id.product_template_attribute_value_ids', 'product_id.product_tmpl_id.attribute_line_ids')
    def _compute_attributes(self):
        color_attrs = {'renk', 'color'}
        size_attrs = {'beden', 'size', 'numara'}
        brand_attrs = {'marka', 'brand'}
        season_attrs = {'sezon', 'sezon/yıl', 'season'}
        gender_attrs = {'cinsiyet', 'gender'}

        for session in self:
            c_ids, s_ids, b_ids, se_ids, g_ids = [], [], [], [], []
            if session.product_id:
                for ptav in session.product_id.product_template_attribute_value_ids:
                    attr_name = ptav.attribute_id.name.lower().strip()
                    if any(a in attr_name for a in color_attrs):
                        c_ids.append(ptav.product_attribute_value_id.id)
                    elif any(a in attr_name for a in size_attrs):
                        s_ids.append(ptav.product_attribute_value_id.id)
                
                for ptal in session.product_id.product_tmpl_id.attribute_line_ids:
                    attr_name = ptal.attribute_id.name.lower().strip()
                    if any(a in attr_name for a in brand_attrs):
                        b_ids.extend(ptal.value_ids.ids)
                    elif any(a in attr_name for a in season_attrs):
                        se_ids.extend(ptal.value_ids.ids)
                    elif any(a in attr_name for a in gender_attrs):
                        g_ids.extend(ptal.value_ids.ids)

            session.color_value_ids = [(6, 0, c_ids)]
            session.size_value_ids = [(6, 0, s_ids)]
            session.brand_value_ids = [(6, 0, b_ids)]
            session.season_value_ids = [(6, 0, se_ids)]
            session.gender_value_ids = [(6, 0, g_ids)]

    # --- Varyant Grubu ---
    apply_to_siblings = fields.Boolean(
        string='Tüm Bedenlere Uygula',
        help='Aynı kesimin tüm beden varyantlarına uygula',
        default=True,
    )
    sibling_product_ids = fields.Many2many(
        'product.product',
        string='Kardeş Varyantlar',
        compute='_compute_siblings',
    )

    # --- Durum ---
    state = fields.Selection([
        ('draft', 'Taslak'),
        ('photos_ready', 'Fotoğraflar Hazır'),
        ('preprocessing', 'Ön İşlem'),
        ('processing', 'AI İşliyor'),
        ('review', 'Onay Bekliyor'),
        ('saving', 'Ürüne Kaydediliyor'),
        ('done', 'Tamamlandı'),
        ('cancelled', 'İptal'),
    ], string='Durum', default='draft', tracking=True, index=True)

    # --- Zaman Damgaları (Bottleneck Analizi) ---
    date_photos_ready = fields.Datetime(string='Fotoğraflar Hazır', readonly=True)
    date_processing_start = fields.Datetime(string='AI Başlama', readonly=True)
    date_review_start = fields.Datetime(string='Onaya Düşme', readonly=True)
    date_done = fields.Datetime(string='Tamamlanma', readonly=True)

    # --- AI Ayarları ---
    model_preset_id = fields.Many2one(
        'ai.studio.model.preset',
        string='Manken Preseti',
        tracking=True,
    )
    scene_id = fields.Many2one(
        'ai.studio.scene',
        string='Sahne / Konsept',
        domain="[('active', '=', True)]",
        tracking=True,
    )
    category = fields.Selection([
        ('tops', 'Üst Giyim'),
        ('bottoms', 'Alt Giyim'),
        ('one_piece', 'Tek Parça / Elbise'),
        ('shoes', 'Ayakkabı'),
        ('bags', 'Çanta'),
        ('accessories', 'Aksesuar'),
        ('auto', 'Otomatik'),
    ], string='Kategori', default='auto')
    quality_mode = fields.Selection([
        ('performance', 'Hızlı'),
        ('balanced', 'Dengeli'),
        ('quality', 'Kaliteli'),
    ], string='Kalite Modu', default='balanced')
    extra_prompt = fields.Text(string='İlave Talimat')
    prompt_template_id = fields.Many2one(
        'ai.studio.prompt.template',
        string='Prompt Şablonu',
    )

    # --- İlişkiler ---
    photo_ids = fields.One2many(
        'ai.studio.photo',
        'session_id',
        string='Fotoğraflar',
    )
    generation_ids = fields.One2many(
        'ai.studio.generation',
        'session_id',
        string='AI Üretimler',
    )

    def action_review_generations(self):
        """Profesyonel inceleme popup'ini acar."""
        self.ensure_one()
        return {
            'type': 'ir.actions.client',
            'tag': 'ugurlar_ai_studio.review_popup',
            'params': {
                'session_id': self.id,
            },
            'target': 'new',
        }

    # -------------------------------------------------------------------------
    # FAL.AI API ENTEGRASYONU
    # -------------------------------------------------------------------------

    # --- Kullanıcılar ---
    user_id = fields.Many2one(
        'res.users',
        string='Operatör',
        default=lambda self: self.env.user,
        tracking=True,
    )
    reviewer_id = fields.Many2one(
        'res.users',
        string='Onayıcı',
    )

    # --- İstatistikler ---
    total_cost = fields.Monetary(
        string='Toplam Maliyet',
        compute='_compute_stats',
        store=True,
        currency_field='currency_id',
    )
    revision_count = fields.Integer(
        string='Toplam Revizyon',
        compute='_compute_stats',
        store=True,
    )
    approval_rate = fields.Float(
        string='Onay Oranı (%)',
        compute='_compute_stats',
        store=True,
        digits=(5, 1),
    )
    photo_count = fields.Integer(
        string='Fotoğraf Sayısı',
        compute='_compute_photo_count',
    )
    generation_count = fields.Integer(
        string='Üretim Sayısı',
        compute='_compute_photo_count',
    )
    currency_id = fields.Many2one(
        'res.currency',
        string='Para Birimi',
        default=lambda self: self.env.ref('base.USD', raise_if_not_found=False),
    )
    company_id = fields.Many2one(
        'res.company',
        string='Şirket',
        default=lambda self: self.env.company,
    )
    
    # --- SEO Alanları ---
    seo_description = fields.Html(
        string='AI SEO Ürün Açıklaması',
        help='Gemini tarafından üretilen ürün açıklaması'
    )
    seo_tags = fields.Char(
        string='SEO Etiketleri',
        help='Gemini tarafından üretilen SEO etiketleri (virgülle ayrılmış)'
    )

    @api.model_create_multi
    def create(self, vals_list):
        """Otomatik sıra numarası ata."""
        for vals in vals_list:
            if vals.get('name', '/') == '/':
                vals['name'] = self.env['ir.sequence'].next_by_code(
                    'ai.studio.session'
                ) or '/'
        return super().create(vals_list)

    @api.depends('product_id')
    def _compute_siblings(self):
        """Aynı template'in diğer varyantlarını bul (Sadece aynı renk olanlar)."""
        for session in self:
            if session.product_id and session.product_id.product_tmpl_id:
                tmpl = session.product_id.product_tmpl_id
                all_siblings = tmpl.product_variant_ids - session.product_id
                
                # Varyantın renk özelliklerini bul
                color_ptavs = session.product_id.product_template_attribute_value_ids.filtered(
                    lambda v: v.attribute_id.display_type == 'color' or 'renk' in v.attribute_id.name.lower() or 'color' in v.attribute_id.name.lower()
                )
                
                valid_siblings = all_siblings
                if color_ptavs:
                    # Renk özelliği varsa, sadece aynı renge sahip varyantları filtrele
                    for color_ptav in color_ptavs:
                        valid_siblings = valid_siblings.filtered(
                            lambda s: color_ptav in s.product_template_attribute_value_ids
                        )
                
                session.sibling_product_ids = valid_siblings
            else:
                session.sibling_product_ids = False

    @api.depends('generation_ids.cost', 'generation_ids.is_approved',
                 'generation_ids.revision_number', 'generation_ids.state')
    def _compute_stats(self):
        """Maliyet, revizyon ve onay istatistiklerini hesapla."""
        for session in self:
            gens = session.generation_ids
            session.total_cost = sum(gens.mapped('cost'))
            session.revision_count = sum(
                max(0, g.revision_number - 1) for g in gens
            )
            done_gens = gens.filtered(lambda g: g.state == 'done')
            if done_gens:
                approved = done_gens.filtered('is_approved')
                session.approval_rate = (len(approved) / len(done_gens)) * 100
            else:
                session.approval_rate = 0.0

    def _compute_photo_count(self):
        for session in self:
            session.photo_count = len(session.photo_ids)
            session.generation_count = len(session.generation_ids)

    def _detect_garment_type(self):
        """Ürünün gerçek tipini otomatik algılar.
        
        Öncelik sırası:
        1. session.category elle seçildiyse (auto değilse) → onu kullan
        2. Ürün adı, kategori, Reyon/Ürün Grubu attribute'larından tespit et
        3. Hiçbiri bulunamazsa preset.garment_type veya 'tops' fallback
        """
        self.ensure_one()
        
        # 1. Elle seçilmiş kategori varsa onu kullan
        if self.category and self.category != 'auto':
            _logger.info('_detect_garment_type: Elle seçilmiş kategori=%s', self.category)
            return self.category
        
        # 2. Ürün bilgilerinden otomatik algıla
        product = self.product_id
        if not product:
            fallback = self.model_preset_id.garment_type if self.model_preset_id else 'tops'
            _logger.info('_detect_garment_type: Ürün yok, fallback=%s', fallback)
            return fallback
        
        # Ürün adı + kategori adı + attribute değerlerini topla
        check_texts = []
        
        # Ürün adı (stored field - thread-safe)
        tmpl = product.product_tmpl_id
        if tmpl and tmpl.name:
            check_texts.append(str(tmpl.name).lower())
        
        # Default code (stored field - thread-safe)
        if product.default_code:
            check_texts.append(product.default_code.lower())
        
        # Template kategori adı (categ_id - stored relation)
        if tmpl and tmpl.categ_id and tmpl.categ_id.name:
            check_texts.append(str(tmpl.categ_id.name).lower())
            # Üst kategorileri de kontrol et
            parent = tmpl.categ_id.parent_id
            while parent:
                if parent.name:
                    check_texts.append(str(parent.name).lower())
                parent = parent.parent_id
        
        # Template attribute'ları (Reyon, Ürün Grubu)
        if tmpl:
            try:
                for line in tmpl.attribute_line_ids:
                    attr_name = line.attribute_id.name or ''
                    if attr_name in ('Reyon', 'Ürün Grubu'):
                        for val in line.value_ids:
                            if val.name:
                                check_texts.append(str(val.name).lower())
            except Exception as e:
                _logger.warning('_detect_garment_type: Attribute okuma hatası: %s', e)
        
        combined = ' '.join(check_texts)
        _logger.info('_detect_garment_type: Kontrol metni: "%s"', combined[:200])
        
        # Anahtar kelime eşleştirme
        BAGS_KW = ['çanta', 'canta', 'bag', 'bags', 'clutch', 'el çantası', 'sırt çantası', 'valiz', 'portföy']
        SHOES_KW = ['ayakkabı', 'ayakkabi', 'shoe', 'shoes', 'bot', 'çizme', 'cizme', 'terlik', 
                     'sandalet', 'sneaker', 'spor ayakkabı', 'topuklu', 'loafer', 'babet', 'slip-on',
                     'slipper', 'mule', 'stiletto']
        ACCESSORIES_KW = ['aksesuar', 'accessory', 'accessories', 'kemer', 'belt', 'şal', 'sal', 
                          'fular', 'atkı', 'atki', 'bere', 'şapka', 'sapka', 'gözlük', 'gozluk',
                          'saat', 'watch', 'bileklik', 'kolye', 'küpe', 'kupe', 'yüzük', 'yuzuk',
                          'cüzdan', 'cuzdan', 'eldiven']
        BOTTOMS_KW = ['pantolon', 'jean', 'jeans', 'şort', 'sort', 'etek', 'tayt', 'eşofman altı',
                      'alt giyim', 'bermuda', 'capri', 'jogger']
        ONE_PIECE_KW = ['elbise', 'dress', 'tulum', 'jumpsuit', 'overall', 'abiye', 'tek parça']
        
        for kw in BAGS_KW:
            if kw in combined:
                _logger.info('_detect_garment_type: "%s" bulundu → bags', kw)
                return 'bags'
        for kw in SHOES_KW:
            if kw in combined:
                _logger.info('_detect_garment_type: "%s" bulundu → shoes', kw)
                return 'shoes'
        for kw in ACCESSORIES_KW:
            if kw in combined:
                _logger.info('_detect_garment_type: "%s" bulundu → accessories', kw)
                return 'accessories'
        for kw in ONE_PIECE_KW:
            if kw in combined:
                _logger.info('_detect_garment_type: "%s" bulundu → one_piece', kw)
                return 'one_piece'
        for kw in BOTTOMS_KW:
            if kw in combined:
                _logger.info('_detect_garment_type: "%s" bulundu → bottoms', kw)
                return 'bottoms'
        
        # 3. Fallback: preset veya tops
        fallback = self.model_preset_id.garment_type if self.model_preset_id else 'tops'
        _logger.info('_detect_garment_type: Eşleşme yok, fallback=%s', fallback)
        return fallback

    def _crop_image_detail(self, image_base64, category='tops'):
        """Base64 formatındaki resmi Pillow ile kırpar ve base64 döner.
        
        Kategoriye göre kırpma koordinatları:
        - tops: Göğüs/yaka hizası (üst gövde merkez)
        - bottoms: Kalça/cep hizası (alt gövde merkez)
        - one_piece: Bel hizası (orta gövde)
        - shoes: Alt kısım (ayak bölgesi)
        - bags: Merkez (çantanın gövdesi)
        - accessories: Merkez (ürünün tamamı, geniş kırpma)
        """
        if not image_base64:
            return False
        try:
            import io
            import base64
            from PIL import Image
            
            # Base64 decode
            img_data = base64.b64decode(image_base64)
            img = Image.open(io.BytesIO(img_data))
            w, h = img.size
            
            # Kategoriye göre kırpma koordinatları
            crop_coords = {
                'tops': {
                    # Üst giyim: göğüs/yaka hizası
                    'left': 0.22, 'top': 0.20, 'right': 0.78, 'bottom': 0.55,
                },
                'bottoms': {
                    # Alt giyim: kalça/cep hizası
                    'left': 0.20, 'top': 0.42, 'right': 0.80, 'bottom': 0.75,
                },
                'one_piece': {
                    # Elbise/tek parça: bel hizası
                    'left': 0.18, 'top': 0.30, 'right': 0.82, 'bottom': 0.65,
                },
                'shoes': {
                    # Ayakkabı: alt kısım (ayak bölgesi)
                    'left': 0.10, 'top': 0.60, 'right': 0.90, 'bottom': 0.95,
                },
                'bags': {
                    # Çanta: merkez gövde
                    'left': 0.15, 'top': 0.15, 'right': 0.85, 'bottom': 0.85,
                },
                'accessories': {
                    # Aksesuar: geniş merkez
                    'left': 0.10, 'top': 0.10, 'right': 0.90, 'bottom': 0.90,
                },
            }
            
            coords = crop_coords.get(category, crop_coords['tops'])
            left = int(w * coords['left'])
            top = int(h * coords['top'])
            right = int(w * coords['right'])
            bottom = int(h * coords['bottom'])
                
            # Kırpma işlemi
            cropped_img = img.crop((left, top, right, bottom))
            
            # Tekrar base64'e dönüştür
            buffered = io.BytesIO()
            img_format = img.format or 'JPEG'
            cropped_img.save(buffered, format=img_format, quality=95)
            return base64.b64encode(buffered.getvalue())
        except Exception as e:
            _logger.error("Kırpma hatası: %s", e)
            return image_base64

    def _generate_inpainting_mask(self, image_base64, garment_type='tops'):
        """Base64 resmin boyutunda inpainting maskesi üretir.
        
        Tops: Belden aşağısını (pants/shoes) inpaint et. (y > h * 0.44)
        Bottoms: Belden yukarısını (tops/face) inpaint et. (y < h * 0.44)
        Full-body/Dress: Sadece ayakları (shoes) inpaint et. (y > h * 0.82)
        """
        if not image_base64:
            return False
        try:
            import io
            import base64
            from PIL import Image, ImageDraw
            
            img_data = base64.b64decode(image_base64)
            img = Image.open(io.BytesIO(img_data))
            w, h = img.size
            
            # Siyah maske oluştur (0 = edit yok)
            mask = Image.new("L", (w, h), 0)
            draw = ImageDraw.Draw(mask)
            
            category = garment_type or 'tops'
            if category == 'tops':
                # Üst giyim: alt kısmı boya (white = edit et)
                draw.rectangle([0, int(h * 0.44), w, h], fill=255)
            elif category == 'bottoms':
                # Alt giyim: üst kısmı boya
                draw.rectangle([0, 0, w, int(h * 0.44)], fill=255)
            else:
                # Full-body/elbise: sadece ayakkabı bölgesini boya
                draw.rectangle([0, int(h * 0.82), w, h], fill=255)
                
            buffered = io.BytesIO()
            mask.save(buffered, format="PNG")
            return base64.b64encode(buffered.getvalue())
        except Exception as e:
            _logger.error("Maske üretme hatası: %s", e)
            return False

    def _remove_hanger_hook(self, image_base64):
        """Gorseldeki aski kancasini ve etiketleri temizler.

        Yontem:
        1. Ust %20'lik alani tara
        2. Dar cikintilari (aski kancasi) tespit et
        3. OpenCV inpainting ile temizle
        4. Alternatif: piksel bazli temizleme (OpenCV yoksa)
        """
        if not image_base64:
            return image_base64
        try:
            import io
            import base64
            from PIL import Image

            img_data = base64.b64decode(image_base64)
            img = Image.open(io.BytesIO(img_data))

            # RGBA moduna cevir
            if img.mode != 'RGBA':
                img = img.convert('RGBA')

            w, h = img.size

            try:
                import cv2
                import numpy as np

                # PIL -> numpy (BGRA)
                img_array = np.array(img)
                alpha = img_array[:, :, 3]

                # Ust %20 alanin maske'sini olustur
                top_region = int(h * 0.20)
                mask = np.zeros((h, w), dtype=np.uint8)

                # Alpha kanalinda opak olan yerleri bul
                _, binary = cv2.threshold(alpha[:top_region], 30, 255, cv2.THRESH_BINARY)

                # Kontur analizi — dar cikintilari bul
                contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

                for cnt in contours:
                    x, y, cw, ch = cv2.boundingRect(cnt)
                    area = cv2.contourArea(cnt)

                    # Aski kancasi ozellikleri:
                    # - Dar (genislik < resim genisliginin %15'i)
                    # - Uzun/ince (yukseklik/genislik orani > 1.5)
                    # - Kucuk alan
                    is_narrow = cw < (w * 0.15)
                    is_tall_and_thin = ch > cw * 1.5 if cw > 0 else False
                    is_small_area = area < (w * h * 0.02)

                    if is_narrow and (is_tall_and_thin or is_small_area):
                        # Bu bir aski kancasi — maskeye ekle
                        cv2.drawContours(mask[:top_region], [cnt], -1, 255, cv2.FILLED)
                        # Etrafina biraz tampon ekle
                        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
                        mask[:top_region] = cv2.dilate(mask[:top_region], kernel, iterations=2)

                # Maske'de temizlenecek alan varsa
                if np.any(mask > 0):
                    # RGB kanallarini al (inpainting icin)
                    rgb = cv2.cvtColor(img_array[:, :, :3], cv2.COLOR_RGBA2BGR)
                    # Inpaint ile temizle
                    inpainted = cv2.inpaint(rgb, mask, inpaintRadius=5, flags=cv2.INPAINT_TELEA)
                    # Maskelenen alanlarin alpha'sini sifirla (seffaf yap)
                    img_array[:, :, 3][mask > 0] = 0

                    result_img = Image.fromarray(img_array)
                    buffered = io.BytesIO()
                    result_img.save(buffered, format='PNG')
                    _logger.info('Aski kancasi temizlendi (OpenCV inpainting)')
                    return base64.b64encode(buffered.getvalue())
                else:
                    # Temizlenecek alan yok
                    return image_base64

            except ImportError:
                # OpenCV yoksa eski yontem (piksel bazli)
                pixels = img.load()
                for y in range(int(h * 0.25)):
                    non_transparent_count = 0
                    for x in range(w):
                        r, g, b, a = pixels[x, y]
                        if a > 30:
                            non_transparent_count += 1

                    if non_transparent_count > 0 and non_transparent_count < (w * 0.10):
                        for x in range(w):
                            pixels[x, y] = (0, 0, 0, 0)
                    elif non_transparent_count >= (w * 0.10):
                        break

                buffered = io.BytesIO()
                img.save(buffered, format='PNG')
                return base64.b64encode(buffered.getvalue())

        except Exception as e:
            _logger.error("Aski kancasi temizleme hatasi: %s", e)
            return image_base64

    # --- Durum Geçişleri ---

    def action_photos_ready(self):
        """Fotoğraflar çekildi, AI'ya göndermeye hazır."""
        for session in self:
            has_front = any(p.photo_type == 'front' for p in session.photo_ids)
            has_back = any(p.photo_type == 'back' for p in session.photo_ids)
            
            if not has_front and not has_back:
                raise UserError(_('Lütfen ürünün Önünü ve Arkasını çekiniz!'))
            if not has_front:
                raise UserError(_('Lütfen ürünün Önünü çekiniz!'))
            if not has_back:
                raise UserError(_('Lütfen ürünün Arkasını çekiniz!'))
                
            session.state = 'photos_ready'
            session.date_photos_ready = fields.Datetime.now()

    def action_start_processing(self):
        """AI işlemeyi başlat."""
        self.ensure_one()
        if not self.model_preset_id:
            raise UserError(_('Lütfen bir manken preseti seçin.'))
        if not self.photo_ids:
            raise UserError(_('Fotoğraf yok. Önce fotoğraf çekin.'))

        # Provider secimi ve API key kontrolu
        provider_type = self.env['ir.config_parameter'].sudo().get_param(
            'ugurlar_ai_studio.default_provider', 'fashn'
        )
        if provider_type == 'fashn':
            api_key = self.env['ir.config_parameter'].sudo().get_param(
                'ugurlar_ai_studio.fashn_api_key'
            )
            if not api_key:
                raise UserError(_(
                    'FASHN API anahtarı ayarlanmamış. '
                    'Ayarlar → AI Stüdyo menüsünden girin.'
                ))
        else:
            api_key = self.env['ir.config_parameter'].sudo().get_param(
                'ugurlar_ai_studio.fal_api_key'
            )
            if not api_key:
                raise UserError(_(
                    'fal.ai API anahtarı ayarlanmamış. '
                    'Ayarlar → AI Stüdyo menüsünden girin.'
                ))

        # Ön yüz fotoğrafını doğrula
        photos_by_type = {p.photo_type: p for p in self.photo_ids}
        front_photo = photos_by_type.get('front')
        if not front_photo:
            raise UserError(_('AI işlemeyi başlatabilmek için en azından Ön Yüz fotoğrafı yüklenmiş olmalıdır.'))

        self.state = 'preprocessing'
        self.date_processing_start = fields.Datetime.now()

        # Eski generation kayıtlarını temizle
        self.generation_ids.unlink()

        # 4 görsel çıktısı için generation kayıtlarını oluştur
        # 1. Ön Görsel
        self.env['ai.studio.generation'].create({
            'session_id': self.id,
            'source_photo_id': front_photo.id,
            'photo_type': 'front',
            'original_image': front_photo.image_original,
            'state': 'pending',
            'provider': provider_type,
        })

        # 2. Arka Görsel (varsa)
        back_photo = photos_by_type.get('back')
        if back_photo:
            self.env['ai.studio.generation'].create({
                'session_id': self.id,
                'source_photo_id': back_photo.id,
                'photo_type': 'back',
                'original_image': back_photo.image_original,
                'state': 'pending',
                'provider': provider_type,
            })

        # 3. Yan Görsel (varsa side_photo, yoksa front_photo kullanılır)
        side_photo = photos_by_type.get('side')
        self.env['ai.studio.generation'].create({
            'session_id': self.id,
            'source_photo_id': (side_photo or front_photo).id,
            'photo_type': 'side',
            'original_image': (side_photo or front_photo).image_original,
            'state': 'pending',
            'provider': provider_type,
        })

        # 4. Detay Görsel (varsa detail_photo, yoksa front_photo kullanılır)
        detail_photo = photos_by_type.get('detail')
        self.env['ai.studio.generation'].create({
            'session_id': self.id,
            'source_photo_id': (detail_photo or front_photo).id,
            'photo_type': 'detail',
            'original_image': (detail_photo or front_photo).image_original,
            'state': 'pending',
            'provider': provider_type,
        })

        # Eşzamanlı istek limiti kontrolü
        concurrent_limit = int(self.env['ir.config_parameter'].sudo().get_param(
            'ugurlar_ai_studio.concurrent_limit', '2'
        ))
        active_processing = self.search_count([
            ('state', '=', 'processing'),
            ('id', '!=', self.id),
        ])
        if active_processing >= concurrent_limit:
            _logger.warning(
                'Eşzamanlı AI işlem limiti (%d) aşıldı. '
                'Aktif: %d. İşlem yine de başlatılıyor (kuyrukta bekleyecek).',
                concurrent_limit, active_processing,
            )

        # Arka planda AI işlemeyi başlat
        thread = threading.Thread(
            target=self._process_ai_thread,
            args=(self.id, api_key, self.env.uid),
        )
        thread.daemon = True
        thread.start()

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('AI İşleme Başladı'),
                'message': _('Fotoğraflar AI tarafından işleniyor. Tamamlandığında bildirim alacaksınız.'),
                'type': 'info',
                'sticky': False,
            },
        }

    @staticmethod
    def _create_provider(api_key, provider_type='fashn'):
        """Ayardaki secime gore provider olustur."""
        if provider_type == 'fashn':
            from ..services.fashn_provider import FashnProvider
            return FashnProvider(api_key)
        else:
            from ..services.fal_provider import FalProvider
            return FalProvider(api_key)

    def _process_single_generation_worker(self, session_id, gen_id, api_key, front_result_b64, outfit_consistency, front_seed, cached_analysis_data=None):
        """Worker thread for processing a single generation (used for parallelizing back and side views)."""
        _logger.info('Worker thread baslatildi (gen_id=%s)', gen_id)
        
        with self.pool.cursor() as cr:
            env = api.Environment(cr, self.env.uid, {})
            session = env['ai.studio.session'].browse(session_id)
            gen = env['ai.studio.generation'].browse(gen_id)
            preset = session.model_preset_id
            
            provider_type = env['ir.config_parameter'].sudo().get_param(
                'ugurlar_ai_studio.default_provider', 'fashn'
            )
            fal_api_key = env['ir.config_parameter'].sudo().get_param(
                'ugurlar_ai_studio.fal_api_key', ''
            )
            gemini_api_key = env['ir.config_parameter'].sudo().get_param(
                'ugurlar_ai_studio.gemini_api_key', ''
            )
            
            try:
                provider = self._create_provider(api_key, provider_type)
            except Exception as e:
                _logger.error('Worker AI provider olusturma hatasi: %s', e)
                return

            try:
                gen.write({'state': 'processing'})
                cr.commit()

                start_time = time.time()
                source_image = gen.original_image
                photo_type = gen.photo_type or 'front'

                # ═══ GÖRSEL ÖN İŞLEME PIPELINE ═══
                from ..services.garment_preprocessor import (
                    preprocess_garment_image,
                    convert_birefnet_output_to_rgb,
                )

                preprocessed = preprocess_garment_image(
                    source_image,
                    target_long_edge=1200,  # Yuksek cozunurluk: detay korumasi icin
                )
                processed_b64 = preprocessed['image_base64']

                # ═══ APILER İÇİN URL VE FORMAT AYARLARI ═══
                model_image_field = 'model_image_front'
                if photo_type == 'back':
                    model_image_field = 'model_image_back'
                elif photo_type == 'side':
                    model_image_field = 'model_image_side'

                model_image_data = getattr(preset, model_image_field)
                if not model_image_data:
                    model_image_data = preset.model_image_front

                # Upload images
                model_url = provider.upload_image(model_image_data)
                garment_url = provider.upload_image(processed_b64)
                front_output_url = None
                if front_result_b64:
                    try:
                        front_output_url = provider.upload_image(front_result_b64)
                    except Exception:
                        pass
                        
                detail_urls = []
                # Detay fotoğraflarını mevcut view'a göre filtrele
                detail_placement_filter = photo_type if photo_type in ('front', 'back') else 'front'
                detail_photos = env['ai.studio.photo'].search([
                    ('session_id', '=', session_id),
                    ('photo_type', '=', 'detail'),
                    ('detail_placement', '=', detail_placement_filter),
                ])
                # Geriye uyumluluk / Fallback İPTAL: Sadece ilgili view'ın detay fotoğrafları gönderilir.
                # Bu sayede ön yüzdeki desen/cepler arka yüze taşmaz.
                for dp in detail_photos:
                    try:
                        dp_url = provider.upload_image(dp.image_original)
                        detail_urls.append(dp_url)
                    except Exception:
                        pass

                # ⚠️ DOKUNMA! nano-banana-2/edit sabit kalmalı — redux/image-to-image gibi alternatifleri KULLANMA
                tryon_model = 'nano-banana-2/edit' if provider_type == 'fal' else 'tryon-v1.6'
                tryon_resolution = '2K'  # Detay korumasi icin 2K zorunlu
                if provider_type == 'fashn':
                    tryon_model = preset.fashn_model_side if photo_type == 'side' else (preset.fashn_model_back if photo_type == 'back' else preset.fashn_model_front)
                    if not tryon_model:
                        tryon_model = 'tryon-v1.6'
                    tryon_resolution = '2K' if 'max' in tryon_model else '1K'

                # category mapping
                from ..services.garment_analyzer import map_to_fashn_category
                category_to_send = map_to_fashn_category(cached_analysis_data or {})

                # ═══ VIEW-SPESİFİK PROMPT ═══
                prompt_text = ""
                try:
                    all_locks = env['ai.studio.prompt.template'].search([
                        ('scope', '=', 'global'),
                        ('active', '=', True),
                    ])
                    prompt_locks = [l.prompt_text for l in all_locks]

                    from ..services.garment_analyzer import build_generation_prompt
                    
                    combined_extra_prompt = session.extra_prompt or ''
                    if session.scene_id and session.scene_id.prompt_additions:
                        combined_extra_prompt += f" {session.scene_id.prompt_additions}"
                        
                    built_prompt = build_generation_prompt(
                        cached_analysis_data or {}, {
                            'gender': preset.gender or 'female',
                            'body_type': preset.body_type or 'standard',
                            'target_audience': preset.target_audience or '',
                        },
                        prompt_locks,
                        combined_extra_prompt.strip(),
                        photo_type=photo_type,
                        outfit_consistency=outfit_consistency,
                        provider_type=provider_type,
                    )
                    prompt_text = built_prompt.get('positive', '')
                    negative_prompt_text = built_prompt.get('negative', '')
                    
                    if session.scene_id and session.scene_id.negative_prompt_additions:
                        if negative_prompt_text:
                            negative_prompt_text += f", {session.scene_id.negative_prompt_additions}"
                        else:
                            negative_prompt_text = session.scene_id.negative_prompt_additions
                except Exception as pe:
                    _logger.warning('Worker: Prompt olusturma basarisiz (gen=%s): %s', gen.id, pe)

                # ═══ TRY-ON API ÇAĞRISI ═══
                tryon_result = provider.virtual_tryon(
                    model_image_url=model_url,
                    garment_image_url=garment_url,
                    category=category_to_send,
                    mode=session.quality_mode or 'quality',
                    model_name=tryon_model,
                    num_samples=1,
                    garment_photo_type='auto',
                    output_format='jpeg',
                    prompt=prompt_text,
                    negative_prompt=negative_prompt_text,
                    front_output_url=front_output_url,
                    detail_urls=detail_urls,
                    resolution=tryon_resolution,
                    photo_type=photo_type,
                    seed=front_seed,
                )

                elapsed = time.time() - start_time

                # ═══ SONUCU İNDİR ═══
                import requests as req_lib
                import base64
                output_url = tryon_result.get('image_url', '')
                if not output_url:
                    image_urls = tryon_result.get('image_urls', [])
                    output_url = image_urls[0] if image_urls else ''

                if output_url:
                    if output_url.startswith('data:'):
                        raw = output_url.split(';base64,', 1)[1]
                        img_data = base64.b64decode(raw)
                    else:
                        img_data = req_lib.get(output_url, timeout=60).content

                    gen_b64 = base64.b64encode(img_data)
                    gen_seed = tryon_result.get('seed') or False

                    gen.write({
                        'generated_image': gen_b64,
                        'state': 'done',
                        'fal_endpoint': '%s/%s' % (provider_type, tryon_model),
                        'generation_time_seconds': elapsed,
                        'cost': tryon_result.get('cost', 0.05),
                        'seed': gen_seed,
                    })

                    # ═══ BACK/SIDE POST-PROCESSING: OUTFIT TUTARLILIĞI ═══
                    # DEVRE DIŞI: flux/schnell/image-to-image endpoint'i kaldırıldı.
                    # redux endpoint'i yanlış sonuç üretiyordu.
                    # nano-banana-2 zaten yeterli kalitede sonuç veriyor.
                    if False and front_result_b64 and outfit_consistency:
                        consistency_prompt = outfit_consistency.get('fullOutfitPrompt', '')
                        if consistency_prompt:
                            try:
                                _logger.info(
                                    'Worker: Post-processing outfit tutarliligi (flux-img2img+ipadapter) baslatiliyor (gen=%s, tip=%s)',
                                    gen.id, photo_type,
                                )
                                front_ref_url = provider.upload_image(front_result_b64)
                                current_url = provider.upload_image(gen_b64)

                                bottoms_desc = outfit_consistency.get('bottomsColor', '') + ' ' + outfit_consistency.get('bottomsType', '')
                                shoes_desc = outfit_consistency.get('shoesColor', '') + ' ' + outfit_consistency.get('shoesType', '')

                                edit_prompt = (
                                    f"RAW photo, photorealistic, professional fashion photography, studio lighting, white background. "
                                    f"A model wearing a top garment, matching the outfit from the reference image. "
                                    f"The model must wear the exact same {bottoms_desc.strip()} and the exact same {shoes_desc.strip()} "
                                    f"as shown in the reference image. Perfect color tone matching, high detail, 8k resolution."
                                )

                                import os
                                os.environ['FAL_KEY'] = fal_api_key

                                try:
                                    import fal_client
                                except ImportError:
                                    fal_client = None

                                if fal_client:
                                    # Maske üret ve fal.ai'a yükle
                                    mask_b64 = session._generate_inpainting_mask(gen_b64, garment_type=preset.garment_type or 'tops')
                                    mask_url = provider.upload_image(mask_b64) if mask_b64 else None

                                    arguments_to_send = {
                                        'prompt': edit_prompt,
                                        'image_url': current_url,
                                        'strength': 0.82,  # Maskeli alan için yüksek inpainting gücü
                                        'ip_adapters': [
                                            {
                                                'image_url': front_ref_url,
                                                'conditioning_scale': 0.85,
                                            }
                                        ],
                                        'num_images': 1,
                                        'aspect_ratio': '3:4',
                                        'enable_safety_checker': True,
                                    }
                                    if mask_url:
                                        arguments_to_send['mask_url'] = mask_url

                                    edit_result = fal_client.subscribe(
                                        'fal-ai/flux/schnell/redux',
                                        arguments=arguments_to_send,
                                        client_timeout=300,
                                    )
                                    edit_images = edit_result.get('images', [])
                                    if edit_images:
                                        edit_url = edit_images[0].get('url', '')
                                        if edit_url:
                                            edit_data = req_lib.get(edit_url, timeout=60).content
                                            edited_b64 = base64.b64encode(edit_data)
                                            gen.write({
                                                'generated_image': edited_b64,
                                                'fal_endpoint': '%s/%s+consistency' % (provider_type, tryon_model),
                                                'cost': tryon_result.get('cost', 0.05) + 0.03,
                                            })
                                            gen_b64 = edited_b64
                                            _logger.info('Worker: Post-processing outfit tutarliligi tamamlandi (gen=%s)', gen.id)
                            except Exception as pp_e:
                                _logger.warning('Worker: Post-processing outfit tutarliligi basarisiz (gen=%s): %s', gen.id, pp_e)

                    # ═══ KALİTE KONTROL ═══
                    try:
                        from ..services.quality_checker import compute_quality_score
                        qc = compute_quality_score(source_image, gen_b64)
                        gen.write({
                            'quality_score': qc['score'],
                            'quality_details': qc['details'],
                        })
                    except Exception as qe:
                        _logger.debug('Worker: Kalite kontrol hatasi: %s', qe)

                else:
                    gen.write({
                        'state': 'failed',
                        'error_message': 'API sonuç döndürmedi.',
                    })

                cr.commit()

            except Exception as e:
                from ..services.fal_error_handler import parse_fal_error
                parsed = parse_fal_error(e)
                _logger.error('Worker: AI üretim hatası (gen=%s): %s', gen_id, e)
                gen.write({
                    'state': 'failed',
                    'error_message': parsed['message'][:500],
                })
                cr.commit()

    def _process_ai_thread(self, session_id, api_key, uid):
        """Thread içinde tüm generation'ları işle (wrapper)."""
        try:
            self._process_ai_thread_body(session_id, api_key, uid)
        except Exception as thread_err:
            _logger.exception("AI Thread: Beklenmeyen kritik hata olustu: %s", thread_err)
            try:
                with self.pool.cursor() as cr:
                    env = api.Environment(cr, uid, {})
                    session = env['ai.studio.session'].browse(session_id)
                    session.write({'state': 'failed'})
                    cr.commit()
                    try:
                        session.message_post(body=_('Kritik Sistem Hatası: %s') % str(thread_err))
                        cr.commit()
                    except Exception as msg_err:
                        _logger.error("AI Thread message_post hatası: %s", msg_err)
            except Exception:
                pass

    def _process_ai_thread_body(self, session_id, api_key, uid):
        """Thread içinde tüm generation'ları işle (body)."""
        _logger.info("AI Thread starting for session %s with uid %s", session_id, uid)
        time.sleep(1.5)  # Wait for main thread transaction to commit and release locks
        with self.pool.cursor() as cr:
            env = api.Environment(cr, uid, {})
            provider_type = env['ir.config_parameter'].sudo().get_param(
                'ugurlar_ai_studio.default_provider', 'fashn'
            )
            fal_api_key = env['ir.config_parameter'].sudo().get_param(
                'ugurlar_ai_studio.fal_api_key', ''
            )
            gemini_api_key = env['ir.config_parameter'].sudo().get_param(
                'ugurlar_ai_studio.gemini_api_key', ''
            )

        try:
            provider = self._create_provider(api_key, provider_type)
        except ImportError as ie:
            _logger.error('AI provider kurulu degil: %s', ie)
            with self.pool.cursor() as cr:
                env = api.Environment(cr, uid, {})
                session = env['ai.studio.session'].browse(session_id)
                session.write({'state': 'draft'})
                session.message_post(
                    body=_('Hata: AI provider Python paketi kurulu değil. (%s)') % str(ie)
                )
            return

        with self.pool.cursor() as cr:
            env = api.Environment(cr, uid, {})
            session = env['ai.studio.session'].browse(session_id)
            session.write({'state': 'processing'})
            cr.commit()

            preset = session.model_preset_id
            generations = session.generation_ids.filtered(
                lambda g: g.state == 'pending'
            )

            auto_bg = env['ir.config_parameter'].sudo().get_param(
                'ugurlar_ai_studio.auto_bg_remove', 'True'
            ) == 'True'

            # ═══ AYARLARI YUKLE ═══
            tryon_model = env['ir.config_parameter'].sudo().get_param(
                'ugurlar_ai_studio.tryon_model', 'tryon-max'
            )
            tryon_resolution = env['ir.config_parameter'].sudo().get_param(
                'ugurlar_ai_studio.tryon_resolution', '2K'
            )

            # ═══ KIYAFET ANALIZINI CACHE'LE (tek API cagrisi) ═══
            cached_analysis = None
            try:
                front_gen = generations.filtered(lambda g: g.photo_type == 'front')
                if front_gen and front_gen[0].original_image:
                    from ..services.garment_preprocessor import preprocess_garment_image
                    _pre = preprocess_garment_image(front_gen[0].original_image, target_long_edge=1200)
                    _pre_url = provider.upload_image(_pre['image_base64'])

                    from ..services.garment_analyzer import analyze_garment
                    cached_analysis = analyze_garment(
                        fal_api_key, _pre_url, gemini_api_key=gemini_api_key
                    )
                    _logger.info(
                        'Kıyafet analizi tamamlandı: %s %s, hasGraphic=%s',
                        cached_analysis.get('garmentType', '?'),
                        cached_analysis.get('primaryColor', '?'),
                        cached_analysis.get('hasGraphic', False),
                    )
            except Exception as ae:
                _logger.warning('Kıyafet analizi başarısız, varsayılan kullanılacak: %s', ae)

            # ═══ TÜM GENERATION'LARI İŞLE ═══
            # Cross-view tutarlılık verisi — front sonrası doldurulur
            outfit_consistency = None
            front_result_b64 = None  # Front try-on sonucu — back/side post-processing referansı
            import random
            front_seed = random.randint(100000, 99999999)  # Front try-on seed'i — back/side çağrıları için referans

            # Sıralama: front → back → side → detail
            ordered_gens = (
                generations.filtered(lambda g: g.photo_type == 'front')
                + generations.filtered(lambda g: g.photo_type == 'back')
                + generations.filtered(lambda g: g.photo_type == 'side')
                + generations.filtered(lambda g: g.photo_type == 'detail')
            )

            front_failed = False
            for gen in ordered_gens:
                photo_type = gen.photo_type or 'front'
                if front_failed:
                    gen.write({
                        'state': 'failed',
                        'error_message': _('Ön yüz üretimi başarısız olduğu için bu işlem iptal edildi.'),
                    })
                    cr.commit()
                    continue

                try:
                    gen.write({'state': 'processing'})
                    cr.commit()

                    start_time = time.time()
                    source_image = gen.original_image

                    from ..services.garment_preprocessor import (
                        preprocess_garment_image,
                        convert_birefnet_output_to_rgb,
                    )

                    preprocessed = preprocess_garment_image(source_image, target_long_edge=1200)
                    processed_b64 = preprocessed['image_base64']

                    # ═══ DETAY FOTOĞRAFI ═══
                    if photo_type == 'detail':
                        garment_cat = session._detect_garment_type()
                        _logger.info('DETAY TİP TESPİT: ürün=%s → algılanan=%s (preset=%s)',
                                     session.product_id.display_name, garment_cat,
                                     preset.garment_type if preset else 'yok')
                        
                        # Ayakkabı/Çanta/Aksesuar → doğrudan ürün fotoğrafından kırp
                        # (Manken try-on sonucunda bu ürünler görünmez)
                        if garment_cat in ('shoes', 'bags', 'accessories'):
                            _logger.info('Detay: %s kategorisi — ürün fotoğrafından kırpılacak (gen=%s)', garment_cat, gen.id)
                            # BG remove + detay kırpma
                            if auto_bg and processed_b64:
                                try:
                                    bg_removed_b64 = provider.remove_background(processed_b64)
                                    bg_removed_data = base64.b64decode(bg_removed_b64)
                                    rgb_data = convert_birefnet_output_to_rgb(bg_removed_data)
                                    clean_b64 = base64.b64encode(rgb_data)
                                except Exception as e:
                                    _logger.warning('BG remove başarısız, orijinal kullanılacak: %s', e)
                                    clean_b64 = processed_b64
                            else:
                                clean_b64 = processed_b64
                            detail_b64 = session._crop_image_detail(clean_b64, category=garment_cat)
                        else:
                            # Üst/Alt/Tek Parça → manken try-on sonucundan kırp
                            target_type = 'front'
                            if gen.source_photo_id and gen.source_photo_id.photo_type == 'detail':
                                if gen.source_photo_id.detail_placement == 'back':
                                    target_type = 'back'

                            target_gen = session.generation_ids.filtered(
                                lambda g: g.photo_type == target_type and g.state == 'done' and g.generated_image
                            )
                            if not target_gen and target_type == 'back':
                                target_gen = session.generation_ids.filtered(
                                    lambda g: g.photo_type == 'front' and g.state == 'done' and g.generated_image
                                )

                            if target_gen:
                                detail_b64 = session._crop_image_detail(
                                    target_gen[0].generated_image,
                                    category=garment_cat
                                )
                                _logger.info('Detay kırpıldı (gen=%s) %s try-on sonucundan', gen.id, target_type)
                            else:
                                _logger.warning('Detay kırpma fallback: try-on sonucu bulunamadı (gen=%s)', gen.id)
                                if auto_bg and processed_b64:
                                    try:
                                        bg_removed_b64 = provider.remove_background(processed_b64)
                                        bg_removed_data = base64.b64decode(bg_removed_b64)
                                        rgb_data = convert_birefnet_output_to_rgb(bg_removed_data)
                                        detail_b64 = base64.b64encode(rgb_data)
                                    except Exception as e:
                                        _logger.warning('Detay BG remove başarısız: %s', e)
                                        detail_b64 = processed_b64
                                else:
                                    detail_b64 = processed_b64

                        elapsed = time.time() - start_time
                        gen.write({
                            'generated_image': detail_b64,
                            'state': 'done',
                            'fal_endpoint': 'detail-crop' if target_gen else ('%s/bg-remove-detail' % provider_type),
                            'generation_time_seconds': elapsed,
                            'cost': 0.0 if target_gen else 0.01,
                        })

                        # KALİTE KONTROL
                        try:
                            from ..services.quality_checker import compute_quality_score
                            qc = compute_quality_score(source_image, detail_b64)
                            gen.write({
                                'quality_score': qc['score'],
                                'quality_details': qc['details'],
                            })
                        except Exception as qe:
                            _logger.debug('Kalite kontrol hatası: %s', qe)

                        cr.commit()
                        continue

                    # ═══ APILER İÇİN URL VE FORMAT AYARLARI ═══
                    model_image_field = 'model_image_front'
                    if photo_type == 'back':
                        model_image_field = 'model_image_back'
                    elif photo_type == 'side':
                        model_image_field = 'model_image_side'

                    model_image_data = getattr(preset, model_image_field)
                    if not model_image_data:
                        model_image_data = preset.model_image_front

                    if not model_image_data:
                        raise UserError(_('Preset manken resmi eksik.'))

                    # Upload images
                    model_url = provider.upload_image(model_image_data)
                    front_output_url = None
                    if front_result_b64:
                        try:
                            front_output_url = provider.upload_image(front_result_b64)
                        except Exception:
                            pass
                            
                    detail_urls = []
                    # Detay fotoğraflarını mevcut view'a göre filtrele
                    detail_placement_filter = photo_type if photo_type in ('front', 'back') else 'front'
                    detail_photos = env['ai.studio.photo'].search([
                        ('session_id', '=', session.id),
                        ('photo_type', '=', 'detail'),
                        ('detail_placement', '=', detail_placement_filter),
                    ])
                    # Geriye uyumluluk / Fallback İPTAL: Sadece ilgili view'ın detay fotoğrafları gönderilir.
                    # Bu sayede ön yüzdeki desen/cepler arka yüze taşmaz.
                    for dp in detail_photos:
                        try:
                            dp_url = provider.upload_image(dp.image_original)
                            detail_urls.append(dp_url)
                        except Exception:
                            pass
                    # Arka plan kaldırma ve askı temizleme
                    if auto_bg and processed_b64:
                        try:
                            bg_removed_b64 = provider.remove_background(processed_b64)
                            try:
                                bg_removed_data = base64.b64decode(bg_removed_b64)
                                rgb_data = convert_birefnet_output_to_rgb(bg_removed_data)
                                rgb_b64 = base64.b64encode(rgb_data)
                            except Exception:
                                rgb_b64 = bg_removed_b64
                            cleaned_b64 = session._remove_hanger_hook(rgb_b64)
                            garment_url = provider.upload_image(cleaned_b64)
                        except Exception as e:
                            _logger.warning('Main BG remove başarısız: %s', e)
                            garment_url = provider.upload_image(processed_b64)
                    else:
                        garment_url = provider.upload_image(processed_b64)

                    # ⚠️ DOKUNMA! nano-banana-2/edit sabit kalmalı — redux/image-to-image gibi alternatifleri KULLANMA
                    tryon_model = 'nano-banana-2/edit' if provider_type == 'fal' else 'tryon-v1.6'
                    tryon_resolution = '2K'  # Detay korumasi icin 2K zorunlu
                    if provider_type == 'fashn':
                        tryon_model = getattr(preset, f'fashn_model_{photo_type}', False) or preset.fashn_model_front or 'tryon-v1.6'
                        tryon_resolution = '2K' if 'max' in tryon_model else '1K'

                    from ..services.garment_analyzer import map_to_fashn_category
                    category_to_send = map_to_fashn_category(cached_analysis)

                    # VIEW-SPESİFİK PROMPT OLUŞTURMA
                    prompt_text = ""
                    try:
                        all_locks = env['ai.studio.prompt.template'].search([
                            ('scope', '=', 'global'),
                            ('active', '=', True),
                        ])
                        prompt_locks = [l.prompt_text for l in all_locks]

                        analysis_data = cached_analysis or {}
                        preset_data = {
                            'gender': preset.gender or 'female',
                            'body_type': preset.body_type or 'standard',
                            'target_audience': preset.target_audience or '',
                        }

                        from ..services.garment_analyzer import build_generation_prompt
                        
                        combined_extra_prompt = session.extra_prompt or ''
                        if session.scene_id and session.scene_id.prompt_additions:
                            combined_extra_prompt += f" {session.scene_id.prompt_additions}"
                            
                        built_prompt = build_generation_prompt(
                            analysis_data, preset_data, prompt_locks,
                            combined_extra_prompt.strip(),
                            photo_type=photo_type,
                            outfit_consistency=outfit_consistency,
                            provider_type=provider_type,
                        )
                        prompt_text = built_prompt.get('positive', '')
                        negative_prompt_text = built_prompt.get('negative', '')
                        
                        if session.scene_id and session.scene_id.negative_prompt_additions:
                            if negative_prompt_text:
                                negative_prompt_text += f", {session.scene_id.negative_prompt_additions}"
                            else:
                                negative_prompt_text = session.scene_id.negative_prompt_additions
                    except Exception as pe:
                        _logger.warning('Prompt oluşturma başarısız: %s', pe)

                    # TRY-ON API ÇAĞRISI
                    tryon_result = provider.virtual_tryon(
                        model_image_url=model_url,
                        garment_image_url=garment_url,
                        category=category_to_send,
                        mode=session.quality_mode or 'quality',
                        model_name=tryon_model,
                        num_samples=1,
                        garment_photo_type='auto',
                        output_format='jpeg',
                        prompt=prompt_text,
                        negative_prompt=negative_prompt_text,
                        front_output_url=front_output_url,
                        detail_urls=detail_urls,
                        resolution=tryon_resolution,
                        photo_type=photo_type,
                        seed=front_seed,
                    )

                    elapsed = time.time() - start_time

                    # SONUCU İNDİR
                    import requests as req_lib
                    output_url = tryon_result.get('image_url', '')
                    if not output_url:
                        image_urls = tryon_result.get('image_urls', [])
                        output_url = image_urls[0] if image_urls else ''

                    if output_url:
                        if output_url.startswith('data:'):
                            raw = output_url.split(';base64,', 1)[1]
                            img_data = base64.b64decode(raw)
                        else:
                            img_data = req_lib.get(output_url, timeout=60).content

                        gen_b64 = base64.b64encode(img_data)
                        gen_seed = tryon_result.get('seed') or False
                        
                        gen.write({
                            'generated_image': gen_b64,
                            'state': 'done',
                            'fal_endpoint': '%s/%s' % (provider_type, tryon_model),
                            'generation_time_seconds': elapsed,
                            'cost': tryon_result.get('cost', 0.05),
                            'seed': gen_seed,
                        })

                        # ═══ FRONT SONRASI: REFERANS CACHE + OUTFIT ANALİZİ ═══
                        if photo_type == 'front':
                            if gen_seed:
                                front_seed = gen_seed

                            # KOMBIN GIYDIRME DEVRE DISI: flux/schnell endpoint kaldirildi.

                            front_result_b64 = gen_b64

                            if outfit_consistency is None:
                                try:
                                    from ..services.garment_analyzer import analyze_outfit_consistency
                                    outfit_consistency = analyze_outfit_consistency(
                                        gen_b64,
                                        api_key=fal_api_key,
                                        gemini_api_key=gemini_api_key,
                                        category=category_to_send,
                                    )
                                except Exception as oe:
                                    _logger.warning('Outfit tutarlılık analizi başarısız: %s', oe)

                        # ═══ BACK/SIDE POST-PROCESSING: OUTFIT TUTARLILIĞI ═══
                        # DEVRE DIŞI: flux/schnell/image-to-image endpoint'i kaldırıldı.
                        if False and photo_type in ('back', 'side') and front_result_b64 and outfit_consistency:
                            consistency_prompt = outfit_consistency.get('fullOutfitPrompt', '')
                            if consistency_prompt:
                                try:
                                    _logger.info(
                                        'Post-processing outfit tutarlılığı (flux-img2img+ipadapter) başlatılıyor (gen=%s, tip=%s)',
                                        gen.id, photo_type,
                                    )
                                    front_ref_url = provider.upload_image(front_result_b64)
                                    current_url = provider.upload_image(gen_b64)

                                    bottoms_desc = outfit_consistency.get('bottomsColor', '') + ' ' + outfit_consistency.get('bottomsType', '')
                                    shoes_desc = outfit_consistency.get('shoesColor', '') + ' ' + outfit_consistency.get('shoesType', '')

                                    top_color = (cached_analysis or {}).get('primaryColor', '')
                                    top_type = (cached_analysis or {}).get('garmentType', 'garment')
                                    top_desc = f"{top_color} {top_type}".strip()

                                    edit_prompt = (
                                        f"RAW photo, photorealistic, professional fashion photography, studio lighting, white background. "
                                        f"A model wearing a {top_desc}, matching the outfit from the reference image. "
                                        f"The model must wear the exact same {bottoms_desc.strip()} and the exact same {shoes_desc.strip()} "
                                        f"as shown in the reference image. The {top_desc} MUST REMAIN {top_color}. Perfect color tone matching, high detail, 8k resolution."
                                    )

                                    import os
                                    os.environ['FAL_KEY'] = fal_api_key

                                    try:
                                        import fal_client
                                    except ImportError:
                                        fal_client = None

                                    if fal_client:
                                        mask_b64 = session._generate_inpainting_mask(gen_b64, garment_type=preset.garment_type or 'tops')
                                        mask_url = provider.upload_image(mask_b64) if mask_b64 else None

                                        arguments_to_send = {
                                            'prompt': edit_prompt,
                                            'image_url': current_url,
                                            'strength': 0.82,
                                            'ip_adapters': [
                                                {
                                                    'image_url': front_ref_url,
                                                    'conditioning_scale': 0.85,
                                                }
                                            ],
                                            'num_images': 1,
                                            'aspect_ratio': '3:4',
                                            'enable_safety_checker': True,
                                        }
                                        if mask_url:
                                            arguments_to_send['mask_url'] = mask_url
                                        if front_seed:
                                            arguments_to_send['seed'] = int(front_seed)

                                        # Rate Limit / Concurrency Limit Retry Mekanizması
                                        # import time
                                        max_retries = 3
                                        backoff_factor = 4
                                        edit_result = None
                                        for attempt in range(max_retries):
                                            try:
                                                edit_result = fal_client.subscribe(
                                                    'fal-ai/flux/schnell/redux',
                                                    arguments=arguments_to_send,
                                                    client_timeout=300,
                                                )
                                                break
                                            except Exception as e:
                                                error_str = str(e).lower()
                                                is_rate_limit = (
                                                    'rate' in error_str or
                                                    'limit' in error_str or
                                                    '429' in error_str or
                                                    'concurrent' in error_str
                                                )
                                                if is_rate_limit and attempt < max_retries - 1:
                                                    sleep_time = backoff_factor * (2 ** attempt)
                                                    _logger.warning(
                                                        "Back/Side post-process Rate Limit asildi. %d saniye beklenip tekrar denenecek (Deneme %d/%d). Hata: %s",
                                                        sleep_time, attempt + 1, max_retries, e
                                                    )
                                                    time.sleep(sleep_time)
                                                else:
                                                    raise
                                        edit_images = edit_result.get('images', [])
                                        if edit_images:
                                            edit_url = edit_images[0].get('url', '')
                                            if edit_url:
                                                edit_data = req_lib.get(edit_url, timeout=60).content
                                                edited_b64 = base64.b64encode(edit_data)
                                                gen.write({
                                                    'generated_image': edited_b64,
                                                    'fal_endpoint': '%s/%s+consistency' % (provider_type, tryon_model),
                                                    'cost': tryon_result.get('cost', 0.05) + 0.03,
                                                })
                                                gen_b64 = edited_b64
                                                _logger.info('Post-processing outfit tutarlılığı tamamlandı (gen=%s, tip=%s)', gen.id, photo_type)
                                except Exception as pp_e:
                                    _logger.warning('Post-processing outfit tutarlılığı başarısız (gen=%s): %s', gen.id, pp_e)

                        # KALİTE KONTROL
                        try:
                            from ..services.quality_checker import compute_quality_score
                            qc = compute_quality_score(source_image, gen_b64)
                            gen.write({
                                'quality_score': qc['score'],
                                'quality_details': qc['details'],
                            })
                        except Exception as qe:
                            _logger.debug('Kalite kontrol hatası: %s', qe)

                    else:
                        gen.write({
                            'state': 'failed',
                            'error_message': 'API sonuç döndürmedi.',
                        })
                        if photo_type == 'front':
                            front_failed = True

                    cr.commit()

                except Exception as e:
                    cr.rollback()
                    from ..services.fal_error_handler import parse_fal_error
                    parsed = parse_fal_error(e)
                    _logger.error('AI üretim hatası (gen=%s): %s', gen.id, e)
                    try:
                        gen.write({
                            'state': 'failed',
                            'error_message': parsed['message'][:500],
                        })
                        if photo_type == 'front':
                            front_failed = True
                        cr.commit()
                    except Exception as db_e:
                        cr.rollback()
                        _logger.error('Uretim hatasi kaydedilemedi (gen=%s): %s', gen.id, db_e)

            # ═══ TÜM ÜRETİMLER TAMAMLANDI ═══
            has_failed = any(g.state == 'failed' for g in session.generation_ids)
            final_state = 'failed' if has_failed else 'review'
            
            session.write({
                'state': final_state,
                'date_review_start': fields.Datetime.now()
            })
            if has_failed:
                session.message_post(body=_('AI üretimi tamamlandı ancak BAZI GÖRSELLER BAŞARISIZ oldu. İncele butonuna basarak başarısız olanları tekrar deneyebilirsiniz.'))
            else:
                session.message_post(body=_('AI üretimi tamamlandı. %d görsel onay bekliyor.') % len(session.generation_ids))
            cr.commit()

    def _process_single_generation(self, generation):
        """Tek bir generation'ı yeniden işle (retry için)."""
        provider_type = self.env['ir.config_parameter'].sudo().get_param(
            'ugurlar_ai_studio.default_provider', 'fashn'
        )
        if provider_type == 'fashn':
            api_key = self.env['ir.config_parameter'].sudo().get_param(
                'ugurlar_ai_studio.fashn_api_key'
            )
        else:
            api_key = self.env['ir.config_parameter'].sudo().get_param(
                'ugurlar_ai_studio.fal_api_key'
            )
        if not api_key:
            raise UserError(_('AI API anahtarı ayarlanmamış.'))

        thread = threading.Thread(
            target=self._retry_generation_thread,
            args=(self.id, generation.id, api_key, self.env.uid),
        )
        thread.daemon = True
        thread.start()

    def _retry_generation_thread(self, session_id, gen_id, api_key, uid):
        """Tek generation retry thread'i (wrapper)."""
        try:
            self._retry_generation_thread_body(session_id, gen_id, api_key, uid)
        except Exception as thread_err:
            _logger.exception("AI Retry Thread: Beklenmeyen kritik hata olustu: %s", thread_err)
            try:
                with self.pool.cursor() as cr:
                    env = api.Environment(cr, uid, {})
                    gen = env['ai.studio.generation'].browse(gen_id)
                    gen.write({
                        'state': 'failed',
                        'error_message': _('Kritik Sistem Hatası: %s') % str(thread_err),
                    })
                    cr.commit()
            except Exception:
                pass

    def _retry_generation_thread_body(self, session_id, gen_id, api_key, uid):
        """Tek generation retry thread'i (body)."""
        _logger.info("AI Retry Thread starting for session %s, gen %s with uid %s", session_id, gen_id, uid)
        time.sleep(1.5)  # Wait for main thread transaction to commit and release locks
        with self.pool.cursor() as cr:
            env = api.Environment(cr, uid, {})
            provider_type = env['ir.config_parameter'].sudo().get_param(
                'ugurlar_ai_studio.default_provider', 'fashn'
            )
            fal_api_key = env['ir.config_parameter'].sudo().get_param(
                'ugurlar_ai_studio.fal_api_key', ''
            )
            gemini_api_key = env['ir.config_parameter'].sudo().get_param(
                'ugurlar_ai_studio.gemini_api_key', ''
            )
            tryon_model = env['ir.config_parameter'].sudo().get_param(
                'ugurlar_ai_studio.tryon_model', 'tryon-max'
            )
            tryon_resolution = env['ir.config_parameter'].sudo().get_param(
                'ugurlar_ai_studio.tryon_resolution', '2K'
            )

            session = env['ai.studio.session'].browse(session_id)
            gen = env['ai.studio.generation'].browse(gen_id)
            photo_type = gen.photo_type or 'front'

            try:
                provider = self._create_provider(api_key, provider_type)

                _safe_write_and_commit(cr, gen, {'state': 'processing'})

                source_image = gen.original_image
                preset = session.model_preset_id

                # ═══ DETAY İŞLEMİ ═══
                if photo_type == 'detail':
                    garment_cat = session._detect_garment_type()
                    _logger.info('DETAY TİP TESPİT (retry): ürün=%s → algılanan=%s (preset=%s)',
                                 session.product_id.display_name, garment_cat,
                                 preset.garment_type if preset else 'yok')
                    
                    from ..services.garment_preprocessor import (
                        preprocess_garment_image,
                        convert_birefnet_output_to_rgb,
                    )
                    preprocessed = preprocess_garment_image(source_image, target_long_edge=1200)
                    processed_b64 = preprocessed['image_base64']
                    
                    auto_bg = env['ir.config_parameter'].sudo().get_param(
                        'ugurlar_ai_studio.auto_bg_remove', 'True'
                    ) == 'True'
                    
                    # Ayakkabı/Çanta/Aksesuar → doğrudan ürün fotoğrafından kırp
                    if garment_cat in ('shoes', 'bags', 'accessories'):
                        if auto_bg and processed_b64:
                            try:
                                bg_removed_b64 = provider.remove_background(processed_b64)
                                try:
                                    bg_removed_data = base64.b64decode(bg_removed_b64)
                                    rgb_data = convert_birefnet_output_to_rgb(bg_removed_data)
                                    clean_b64 = base64.b64encode(rgb_data)
                                except Exception:
                                    clean_b64 = bg_removed_b64
                            except Exception:
                                clean_b64 = processed_b64
                        else:
                            clean_b64 = processed_b64
                        detail_b64 = session._crop_image_detail(clean_b64, category=garment_cat)
                        crop_source = 'product-detail-crop'
                    else:
                        # Üst/Alt/Tek Parça → manken try-on sonucundan kırp
                        target_type = 'front'
                        if gen.source_photo_id and gen.source_photo_id.photo_type == 'detail':
                            if gen.source_photo_id.detail_placement == 'back':
                                target_type = 'back'

                        target_gen = session.generation_ids.filtered(
                            lambda g: g.photo_type == target_type and g.state == 'done' and g.generated_image
                        )
                        if not target_gen and target_type == 'back':
                            target_gen = session.generation_ids.filtered(
                                lambda g: g.photo_type == 'front' and g.state == 'done' and g.generated_image
                            )

                        if target_gen:
                            detail_b64 = session._crop_image_detail(
                                target_gen[0].generated_image,
                                category=garment_cat
                            )
                            crop_source = 'detail-crop'
                        else:
                            # Fallback: BG remove
                            if auto_bg and processed_b64:
                                try:
                                    bg_removed_b64 = provider.remove_background(processed_b64)
                                    try:
                                        bg_removed_data = base64.b64decode(bg_removed_b64)
                                        rgb_data = convert_birefnet_output_to_rgb(bg_removed_data)
                                        detail_b64 = base64.b64encode(rgb_data)
                                    except Exception:
                                        detail_b64 = bg_removed_b64
                                except Exception:
                                    detail_b64 = processed_b64
                            else:
                                detail_b64 = processed_b64
                            crop_source = '%s/bg-remove-detail' % provider_type

                    gen.write({
                        'generated_image': detail_b64,
                        'state': 'done',
                        'fal_endpoint': crop_source,
                        'error_message': False,
                    })
                    cr.commit()
                    return

                # ═══ TRY-ON RETRY İŞLEMİ ═══
                auto_bg = env['ir.config_parameter'].sudo().get_param(
                    'ugurlar_ai_studio.auto_bg_remove', 'True'
                ) == 'True'

                from ..services.garment_preprocessor import (
                    preprocess_garment_image,
                    convert_birefnet_output_to_rgb,
                )
                preprocessed = preprocess_garment_image(source_image, target_long_edge=1200)
                processed_b64 = preprocessed['image_base64']

                if auto_bg and processed_b64:
                    try:
                        bg_removed_b64 = provider.remove_background(processed_b64)
                        try:
                            bg_removed_data = base64.b64decode(bg_removed_b64)
                            rgb_data = convert_birefnet_output_to_rgb(bg_removed_data)
                            rgb_b64 = base64.b64encode(rgb_data)
                        except Exception:
                            rgb_b64 = bg_removed_b64
                        cleaned_b64 = session._remove_hanger_hook(rgb_b64)
                        garment_url = provider.upload_image(cleaned_b64)
                    except Exception as e:
                        _logger.warning('Retry BG remove başarısız: %s', e)
                        garment_url = provider.upload_image(processed_b64)
                else:
                    garment_url = provider.upload_image(processed_b64)

                model_image_field = 'model_image_front'
                if photo_type == 'back':
                    model_image_field = 'model_image_back'
                elif photo_type == 'side':
                    model_image_field = 'model_image_side'
                model_image = getattr(preset, model_image_field, False) or preset.model_image_front
                if not model_image:
                    raise Exception('Preset manken resmi eksik.')

                model_url = provider.upload_image(model_image)

                cat = session.category
                if provider_type == 'fashn':
                    if cat == 'auto':
                        category_to_send = 'auto'
                    else:
                        category_to_send = {
                            'tops': 'tops',
                            'bottoms': 'bottoms',
                            'one_piece': 'one-pieces',
                        }.get(cat, 'tops')
                else:
                    if cat == 'auto':
                        cat_fallback = preset.garment_type or 'tops'
                        category_to_send = {
                            'tops': 'tops',
                            'bottoms': 'bottoms',
                            'one_piece': 'one-piece',
                        }.get(cat_fallback, 'tops')
                    else:
                        category_to_send = {
                            'tops': 'tops',
                            'bottoms': 'bottoms',
                            'one_piece': 'one-piece',
                        }.get(cat, 'tops')

                # ═══ CROSS-VIEW TUTARLILIK VERİSİ VE BAZ CACHE (Retry İçin) ═══
                outfit_consistency = None
                front_result_b64 = None
                front_output_url = None
                detail_urls = []
                import random
                front_seed = random.randint(100000, 99999999)

                # Detay fotoğraflarını mevcut view'a göre filtrele (tüm photo_type'lar için)
                detail_placement_filter = photo_type if photo_type in ('front', 'back') else 'front'
                detail_photos = env['ai.studio.photo'].search([
                    ('session_id', '=', session.id),
                    ('photo_type', '=', 'detail'),
                    ('detail_placement', '=', detail_placement_filter),
                ])
                # Geriye uyumluluk / Fallback İPTAL: Sadece ilgili view'ın detay fotoğrafları gönderilir.
                # Bu sayede ön yüzdeki desen/cepler arka yüze taşmaz.
                for dp in detail_photos:
                    try:
                        dp_url = provider.upload_image(dp.image_original)
                        detail_urls.append(dp_url)
                    except Exception:
                        pass

                if photo_type in ('back', 'side', 'detail'):
                    # Session içindeki tamamlanmış front kaydını bul
                    front_gen = session.generation_ids.filtered(lambda g: g.photo_type == 'front' and g.state == 'done')
                    if front_gen and front_gen[0].generated_image:
                        front_result_b64 = front_gen[0].generated_image
                        front_seed = front_gen[0].seed or False
                        try:
                            front_output_url = provider.upload_image(front_result_b64)
                        except Exception:
                            pass

                        try:
                            from ..services.garment_analyzer import analyze_outfit_consistency
                            outfit_consistency = analyze_outfit_consistency(
                                front_result_b64,
                                api_key=fal_api_key,
                                gemini_api_key=gemini_api_key,
                                category=category_to_send,
                            )
                        except Exception as oe:
                            _logger.warning('Retry outfit tutarlılık analizi başarısız: %s', oe)

                # ═══ VIEW-SPESİFİK PROMPT ═══
                prompt_text = ""
                try:
                    all_locks = env['ai.studio.prompt.template'].search([
                        ('scope', '=', 'global'),
                        ('active', '=', True),
                    ])
                    prompt_locks = [l.prompt_text for l in all_locks]

                    from ..services.garment_analyzer import analyze_garment, build_generation_prompt
                    analysis = analyze_garment(fal_api_key, garment_url, gemini_api_key=gemini_api_key)

                    preset_data = {
                        'gender': preset.gender or 'female',
                        'body_type': preset.body_type or 'standard',
                        'target_audience': preset.target_audience or '',
                    }

                    built_prompt = build_generation_prompt(
                        analysis, preset_data, prompt_locks,
                        session.extra_prompt or '',
                        photo_type=photo_type,
                        outfit_consistency=outfit_consistency,
                        provider_type=provider_type,
                    )
                    prompt_text = built_prompt.get('positive', '')
                    negative_prompt_text = built_prompt.get('negative', '')
                except Exception as pe:
                    _logger.warning('Failed to build retry prompt: %s', pe)

                if provider_type == 'fal':
                    # ⚠️ DOKUNMA! nano-banana-2/edit sabit kalmalı — redux/image-to-image gibi alternatifleri KULLANMA
                    tryon_model = 'nano-banana-2/edit'
                elif provider_type == 'fashn':
                    tryon_model = getattr(preset, f'fashn_model_{photo_type}', False) or preset.fashn_model_front or 'tryon-v1.6'

                tryon_result = provider.virtual_tryon(
                    model_image_url=model_url,
                    garment_image_url=garment_url,
                    category=category_to_send,
                    mode=session.quality_mode or 'quality',
                    model_name=tryon_model,
                    num_samples=1,
                    garment_photo_type='auto',
                    output_format='jpeg',
                    prompt=prompt_text,
                    negative_prompt=negative_prompt_text,
                    front_output_url=front_output_url,
                    detail_urls=detail_urls,
                    resolution=tryon_resolution,
                    photo_type=photo_type,
                    seed=front_seed,
                )

                output_url = tryon_result.get('image_url', '')
                if not output_url:
                    image_urls = tryon_result.get('image_urls', [])
                    output_url = image_urls[0] if image_urls else ''

                if output_url:
                    if output_url.startswith('data:'):
                        raw_b64 = output_url.split(';base64,', 1)[1]
                        img_data = base64.b64decode(raw_b64)
                    else:
                        import requests
                        img_data = requests.get(output_url, timeout=60).content

                    gen_b64 = base64.b64encode(img_data)
                    gen_seed = tryon_result.get('seed') or False
                    
                    gen_vals = {
                        'generated_image': gen_b64,
                        'state': 'done',
                        'error_message': False,
                        'seed': gen_seed,
                    }

                    # ═══ RETRY BACK/SIDE POST-PROCESSING: OUTFIT TUTARLILIĞI ═══
                    # DEVRE DIŞI: flux/schnell/image-to-image endpoint'i kaldırıldı.
                    if False and photo_type in ('back', 'side') and front_result_b64 and outfit_consistency:
                        consistency_prompt = outfit_consistency.get('fullOutfitPrompt', '')
                        if consistency_prompt:
                            try:
                                _logger.info(
                                    'Retry post-processing outfit tutarlılığı (flux-img2img+ipadapter) başlatılıyor (gen=%s, tip=%s)',
                                    gen.id, photo_type,
                                )
                                front_ref_url = provider.upload_image(front_result_b64)
                                current_url = provider.upload_image(gen_b64)

                                bottoms_desc = outfit_consistency.get('bottomsColor', '') + ' ' + outfit_consistency.get('bottomsType', '')
                                shoes_desc = outfit_consistency.get('shoesColor', '') + ' ' + outfit_consistency.get('shoesType', '')

                                edit_prompt = (
                                    f"RAW photo, photorealistic, professional fashion photography, studio lighting, white background. "
                                    f"A model wearing a top garment, matching the outfit from the reference image. "
                                    f"The model must wear the exact same {bottoms_desc.strip()} and the exact same {shoes_desc.strip()} "
                                    f"as shown in the reference image. Perfect color tone matching, high detail, 8k resolution."
                                )

                                import os
                                os.environ['FAL_KEY'] = fal_api_key

                                try:
                                    import fal_client
                                except ImportError:
                                    fal_client = None

                                if fal_client:
                                    mask_b64 = session._generate_inpainting_mask(gen_b64, garment_type=preset.garment_type or 'tops')
                                    mask_url = provider.upload_image(mask_b64) if mask_b64 else None

                                    arguments_to_send = {
                                        'prompt': edit_prompt,
                                        'image_url': current_url,
                                        'strength': 0.82,
                                        'ip_adapters': [
                                            {
                                                'image_url': front_ref_url,
                                                'conditioning_scale': 0.85,
                                            }
                                        ],
                                        'num_images': 1,
                                        'aspect_ratio': '3:4',
                                        'enable_safety_checker': True,
                                    }
                                    if mask_url:
                                        arguments_to_send['mask_url'] = mask_url
                                    if front_seed:
                                        arguments_to_send['seed'] = int(front_seed)

                                    # Rate Limit / Concurrency Limit Retry Mekanizması
                                    # import time
                                    max_retries = 3
                                    backoff_factor = 4
                                    edit_result = None
                                    for attempt in range(max_retries):
                                        try:
                                            edit_result = fal_client.subscribe(
                                                'fal-ai/flux/schnell/redux',
                                                arguments=arguments_to_send,
                                                client_timeout=300,
                                            )
                                            break
                                        except Exception as e:
                                            error_str = str(e).lower()
                                            is_rate_limit = (
                                                'rate' in error_str or
                                                'limit' in error_str or
                                                '429' in error_str or
                                                'concurrent' in error_str
                                            )
                                            if is_rate_limit and attempt < max_retries - 1:
                                                sleep_time = backoff_factor * (2 ** attempt)
                                                _logger.warning(
                                                    "Retry post-process Rate Limit asildi. %d saniye beklenip tekrar denenecek (Deneme %d/%d). Hata: %s",
                                                    sleep_time, attempt + 1, max_retries, e
                                                )
                                                time.sleep(sleep_time)
                                            else:
                                                raise
                                    edit_images = edit_result.get('images', [])
                                    if edit_images:
                                        edit_url = edit_images[0].get('url', '')
                                        if edit_url:
                                            import requests as req_lib
                                            edit_data = req_lib.get(edit_url, timeout=60).content
                                            edited_b64 = base64.b64encode(edit_data)
                                            gen_vals['generated_image'] = edited_b64
                                            gen_b64 = edited_b64
                                            _logger.info(
                                                'Retry post-processing outfit tutarlılığı tamamlandı (gen=%s, tip=%s)',
                                                gen.id, photo_type,
                                            )
                            except Exception as pp_e:
                                _logger.warning('Retry post-processing outfit tutarlılığı başarısız: %s', pp_e)

                    # Kalite kontrol
                    try:
                        from ..services.quality_checker import compute_quality_score
                        qc = compute_quality_score(source_image, gen_b64)
                        gen_vals['quality_score'] = qc['score']
                        gen_vals['quality_details'] = qc['details']
                    except Exception:
                        pass

                    _safe_write_and_commit(cr, gen, gen_vals)

            except Exception as e:
                cr.rollback()
                from ..services.fal_error_handler import parse_fal_error, format_fal_error_for_log
                parsed = parse_fal_error(e)
                _logger.error('Retry hatası: %s', format_fal_error_for_log(e, f'gen={gen_id}'))
                try:
                    _safe_write_and_commit(cr, gen, {
                        'state': 'failed',
                        'error_message': parsed['message'][:500],
                    })
                except Exception as db_e:
                    cr.rollback()
                    _logger.error('Retry hatasi kaydedilemedi (gen=%s): %s', gen_id, db_e)

            # Session durumu güncellemesi (eğer tüm hatalılar çözüldüyse)
            try:
                if gen.session_id.state == 'failed':
                    all_gens = gen.session_id.generation_ids
                    if not any(g.state == 'failed' for g in all_gens):
                        _safe_write_and_commit(cr, gen.session_id, {'state': 'review'})
            except Exception as se:
                _logger.warning("Retry sonrasi session state guncellenirken hata: %s", se)

    def action_mark_done(self):
        """Onaylanmış görselleri ürüne kaydet ve oturumu tamamla (Asenkron)."""
        self.ensure_one()
        self.action_mark_done_async()
        
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Bilgi'),
                'message': _('Görseller arka planda ürüne kaydediliyor...'),
                'type': 'success',
                'sticky': False,
            }
        }

    def action_mark_done_async(self):
        """Asenkron olarak ürüne kaydetme işlemini cron ile başlatır."""
        self.ensure_one()
        approved = self.generation_ids.filtered(
            lambda g: g.is_approved and g.state == 'done'
        )
        if not approved:
            raise UserError(_('En az bir görsel onaylanmalı.'))
            
        has_primary = approved.filtered(lambda g: g.is_primary)
        if not has_primary:
            raise UserError(_('Lütfen onayladığınız görsellerden birini "Ana Görsel" (Yıldızlı ikon) olarak seçin!'))
            
        self.state = 'saving'
        
        # Odoo'nun cron sistemini tetikle ki güvenli bir environment'te asenkron işlesin
        cron = self.env.ref('ugurlar_ai_studio.cron_save_sessions', raise_if_not_found=False)
        if cron:
            cron._trigger()
        else:
            import logging
            logging.getLogger(__name__).error("cron_save_sessions bulunamadı! Lütfen modülü güncelleyin.")

    @api.model
    def _cron_process_saving_sessions(self):
        """'saving' (Ürüne Kaydediliyor) durumundaki tüm oturumları işler. Cron ile çağrılır."""
        import logging
        _logger = logging.getLogger(__name__)
        
        sessions = self.search([('state', '=', 'saving')])
        for session in sessions:
            _logger.info("CRON: %s numaralı oturum ürünlere kaydediliyor...", session.id)
            try:
                approved = session.generation_ids.filtered(
                    lambda g: g.is_approved and g.state == 'done'
                )
                if not approved:
                    session.state = 'photos_ready'
                    session.message_post(body=_('Hiç onaylı görsel bulunamadı, taslağa döndürüldü.'))
                    continue
                
                # Resimleri ürüne ekle
                session._save_to_product(approved)
                
                session.reviewer_id = self.env.user
                session.state = 'done'
                session.date_done = fields.Datetime.now()
                session.message_post(
                    body=_('Arka planda %d onaylı görsel ürüne başarıyla kaydedildi.') % len(approved),
                )
                self.env.cr.commit()
                _logger.info("CRON: %s numaralı oturum BAŞARIYLA kaydedildi.", session.id)
            except Exception as e:
                self.env.cr.rollback()
                _logger.exception("CRON Hatası (session=%s): %s", session.id, e)
                session.state = 'photos_ready'
                session.message_post(
                    body=_('Arka planda ürüne kaydederken hata oluştu. Lütfen tekrar deneyin. Hata: %s') % str(e)[:200],
                )
                self.env.cr.commit()
    def _save_to_product(self, approved_generations):
        """Onaylanmış görselleri ürün kartına aktar.

        - is_primary olan → ürünün ana resmi (image_1920)
        - Diğerleri → product.image alternatif resimler

        Savepoint kullanarak hata durumunda transaction'ın
        abort olmasını engeller.
        """
        product = self.product_id
        if not product:
            raise UserError(_('Oturuma bağlı ürün bulunamadı.'))

        products = product
        if self.apply_to_siblings and self.sibling_product_ids:
            products |= self.sibling_product_ids

        # Ana resmi bul — tek kayıt garanti
        primary = approved_generations.filtered('is_primary')[:1]
        if not primary:
            # Primary seçilmemişse ilk onaylananı primary yap
            primary = approved_generations[0]
            primary.is_primary = True

        import logging
        _logger = logging.getLogger(__name__)
        _logger.warning("AI_STUDIO_PRIMARY_IMAGE_SIZE: %s", len(primary.generated_image) if primary.generated_image else 0)

        others = approved_generations - primary
        tmpl = product.product_tmpl_id

        # Kilit al: Aynı anda birden fazla oturum aynı ürünü güncellemeye çalışırsa beklet.
        # Bu sayede InFailedSqlTransaction (current transaction is aborted) hatasını kökünden çözer!
        self.env.cr.execute("SELECT id FROM product_template WHERE id = %s FOR NO KEY UPDATE", (tmpl.id,))

        import logging
        _logger = logging.getLogger(__name__)

        def _check_tx(step_name):
            try:
                self.env.cr.execute("SELECT 1")
                _logger.info("TX CHECK %s: OK", step_name)
            except Exception as e:
                _logger.error("TX CHECK %s: FAILED - %s", step_name, e)
                raise e

        _check_tx("After Lock")

        # 1. MEVCUT AI GÖRSELLERİNİ TEMİZLE (Template bazında TEK SEFER)
        existing_ai_images = self.env['product.image'].search([
            ('product_tmpl_id', '=', tmpl.id),
            ('name', 'like', '% - AI (%'),
        ])
        if existing_ai_images:
            existing_ai_images.unlink()
            
        _check_tx("After Unlink")
        
        # 2. ANA RESMİ TEMPLATE'E ATA (Ürünler listesinde görünsün diye)
        try:
            tmpl.image_1920 = primary.generated_image
            tmpl.flush_recordset()
        except Exception as e:
            _logger.error("Template Write ERROR: %s", e)
            raise e
            
        _check_tx("After Template Write")

        # 3. VARYANTLARA ÖZEL ATAMALAR VE EKSTRA RESİMLER
        for prod in products:
            # Varyanta özel ana resim
            if hasattr(prod, 'image_variant_1920'):
                try:
                    prod.image_variant_1920 = primary.generated_image
                    prod.flush_recordset()
                except Exception as e:
                    _logger.error("Variant Write ERROR: %s", e)
                    raise e
            
            _check_tx("After Variant Write")
            
            # Alternatif resimleri bu varyanta özel oluştur
            sequence = 10
            for gen in others:
                type_label = dict(
                    gen._fields['photo_type'].selection
                ).get(gen.photo_type, 'Görsel')
                
                try:
                    self.env['product.image'].create({
                        'product_tmpl_id': tmpl.id,
                        'product_variant_id': prod.id,
                        'name': f'{type_label} - AI ({gen.revision_number})',
                        'image_1920': gen.generated_image,
                        'sequence': sequence,
                    })
                    self.env['product.image'].flush_model()
                except Exception as e:
                    _logger.error("Product Image Create ERROR: %s", e)
                    raise e
                    
                sequence += 10
                
        _check_tx("After Everything")

    def action_cancel(self):
        """Oturumu iptal et."""
        for session in self:
            session.state = 'cancelled'
            session.message_post(body=_('Oturum iptal edildi.'))

    def action_reset_draft(self):
        """Taslak durumuna geri dön."""
        for session in self:
            session.state = 'draft'

    @api.model
    def _cron_check_stuck_generations(self):
        """Processing durumunda 10 dakikadan uzun kalmış üretimleri kontrol et."""
        from datetime import timedelta
        cutoff = fields.Datetime.now() - timedelta(minutes=10)

        stuck_sessions = self.search([
            ('state', 'in', ['preprocessing', 'processing']),
            ('write_date', '<', cutoff),
        ])
        for session in stuck_sessions:
            stuck_gens = session.generation_ids.filtered(
                lambda g: g.state == 'processing' and g.write_date < cutoff
            )
            for gen in stuck_gens:
                gen.write({
                    'state': 'failed',
                    'error_message': 'Zaman aşımı: 10 dakika içinde sonuç alınamadı.',
                })

            # Tüm generation'lar tamamlandıysa review'a geç
            pending = session.generation_ids.filtered(
                lambda g: g.state in ('pending', 'processing')
            )
            if not pending:
                session.write({'state': 'review'})
                session.message_post(
                    body=_('Bazı üretimler zaman aşımına uğradı. Sonuçları kontrol edin.'),
                )

    def write(self, vals):
        res = super(AiStudioSession, self).write(vals)
        if 'state' in vals:
            for record in self:
                if record.state == 'review':
                    # Review durumuna geçtiğinde Aktivite oluşturmayı dene
                    # AMA asla state geçişini engellememelidir
                    try:
                        record._create_review_activities()
                    except Exception as e:
                        _logger.warning("Review aktivite oluşturma başarısız (session=%s): %s", record.id, e)
                elif record.state in ['done', 'cancelled']:
                    # Aktiviteleri kapatmayı dene
                    try:
                        activities = self.env['mail.activity'].search([
                            ('res_id', '=', record.id),
                            ('res_model', '=', 'ai.studio.session')
                        ])
                        for activity in activities:
                            activity.action_done()
                    except Exception as e:
                        _logger.warning("Aktivite kapatma başarısız (session=%s): %s", record.id, e)

                    # Done ise Gemini SEO üretimi tetikle (Thread ile arka planda)
                    if record.state == 'done':
                        try:
                            import threading
                            thread = threading.Thread(target=record._generate_seo_content_gemini_threaded, args=(record.id,))
                            thread.start()
                        except Exception as e:
                            _logger.warning("SEO thread başlatma başarısız (session=%s): %s", record.id, e)
        return res

    def _create_review_activities(self):
        """Review durumuna geçişte onayıcılara aktivite oluşturur."""
        self.ensure_one()
        activity_type = self.env.ref('mail.mail_activity_data_todo', raise_if_not_found=False)
        if not activity_type:
            return

        reviewer_group = self.env.ref('ugurlar_ai_studio.group_ai_studio_reviewer', raise_if_not_found=False)
        if not reviewer_group:
            return

        # Odoo 19 uyumlu: reviewer grubundaki kullanıcıları SQL ile bul
        self.env.cr.execute("""
            SELECT uid FROM res_groups_users_rel WHERE gid = %s
        """, (reviewer_group.id,))
        reviewer_ids = [row[0] for row in self.env.cr.fetchall()]

        if not reviewer_ids:
            return

        # Model ID'sini güvenli şekilde bul
        res_model = self.env['ir.model'].search([('model', '=', 'ai.studio.session')], limit=1)
        if not res_model:
            return

        for reviewer_id in reviewer_ids:
            try:
                self.env['mail.activity'].create({
                    'res_id': self.id,
                    'res_model_id': res_model.id,
                    'activity_type_id': activity_type.id,
                    'summary': _('Çekim Onayı Bekliyor'),
                    'note': _('%s için AI üretimleri tamamlandı. Onayınız bekleniyor.') % self.name,
                    'user_id': reviewer_id,
                })
            except Exception as e:
                _logger.warning("Aktivite oluşturulamadı (user=%s): %s", reviewer_id, e)

    def _generate_seo_content_gemini_threaded(self, session_id):
        """Yeni bir Odoo Environment'i açarak Gemini API çağrısını yapar."""
        import odoo
        from odoo import api, SUPERUSER_ID, registry
        import logging
        _logger = logging.getLogger(__name__)
        
        try:
            db_name = self.env.cr.dbname
            reg = registry(db_name)
            with reg.cursor() as cr:
                env = api.Environment(cr, SUPERUSER_ID, {})
                session = env['ai.studio.session'].browse(session_id)
                session._generate_seo_content_gemini()
        except Exception as e:
            _logger.exception("Gemini Thread error: %s", e)

    def _generate_seo_content_gemini(self):
        """Gemini API kullanarak SEO açıklaması ve etiket üretir."""
        import requests
        import json
        import logging
        _logger = logging.getLogger(__name__)

        api_key = self.env['ir.config_parameter'].sudo().get_param('ugurlar_ai_studio.gemini_api_key')
        if not api_key:
            _logger.info("Gemini API anahtarı ayarlanmamış, SEO üretimi atlanıyor.")
            return

        product = self.product_id
        if not product:
            return

        # Ürün özelliklerini toparla
        attributes_text = ""
        if product.product_template_attribute_value_ids:
            attrs = [f"{v.attribute_id.name}: {v.name}" for v in product.product_template_attribute_value_ids]
            attributes_text = ", ".join(attrs)

        prompt = f"""
Bu fotoğrafı e-ticaret sitemiz için incele. Ürün bilgileri aşağıdadır:
Ürün Adı: {product.name}
Kategori: {product.categ_id.name}
Özellikler: {attributes_text}

Lütfen bu ürün için SEO'ya uygun, ikna edici ve çarpıcı 1 paragraflık bir ürün açıklaması (HTML <p> etiketi içinde) ve SEO için 5 adet etiket (virgülle ayrılmış) üret.
Çıktıyı sadece JSON formatında ver. Format şu şekilde olmalı:
{{
  "seo_description": "<p>Açıklama metni...</p>",
  "seo_tags": "etiket1, etiket2, etiket3, etiket4, etiket5"
}}
"""

        # Gemini API call
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={api_key}"
        headers = {'Content-Type': 'application/json'}
        
        # Primary fotoğrafı bul
        primary_gen = self.generation_ids.filtered('is_primary')[:1]
        if not primary_gen:
            primary_gen = self.generation_ids.filtered('is_approved')[:1]
            
        if not primary_gen or not primary_gen.generated_image:
            _logger.info("Onaylı görsel bulunamadı, SEO üretimi atlanıyor.")
            return

        # Base64 decode string for JSON
        import base64
        image_data = primary_gen.generated_image.decode('utf-8')

        payload = {
            "contents": [{
                "parts": [
                    {"text": prompt},
                    {
                        "inline_data": {
                            "mime_type": "image/jpeg",
                            "data": image_data
                        }
                    }
                ]
            }],
            "generationConfig": {
                "response_mime_type": "application/json",
            }
        }

        try:
            response = requests.post(url, headers=headers, json=payload, timeout=60)
            response.raise_for_status()
            data = response.json()
            
            result_text = data['candidates'][0]['content']['parts'][0]['text']
            result_json = json.loads(result_text)
            
            self.write({
                'seo_description': result_json.get('seo_description', ''),
                'seo_tags': result_json.get('seo_tags', ''),
            })
            self.message_post(body="✨ Gemini SEO İçeriği başarıyla üretildi.")
            self.env.cr.commit()
            
        except Exception as e:
            _logger.error("Gemini API hatası: %s", str(e))
            self.message_post(body=f"⚠️ Gemini SEO Üretimi Başarısız: {str(e)[:200]}")
